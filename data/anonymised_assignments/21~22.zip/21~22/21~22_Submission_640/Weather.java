
/**
 * Enumeration class Weather - creates the values of rain fog and no weather
 *
 * @version(1.3.22)
 */
public enum Weather
{
    rain,fog,nothing
    
    

   

}
