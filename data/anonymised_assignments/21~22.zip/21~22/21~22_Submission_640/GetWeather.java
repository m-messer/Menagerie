import java.util.Random;
import java.awt.Color;
/**
 * This class is where it changes the states of the weather 
 *
 
 */
public class GetWeather
{
    public Weather weather;
    
    private int x ;
    Random rand = new Random();
    
    public GetWeather(){
        //initialises it to no wather
        weather=weather.nothing;
        
    }
    /**
     * Returns a weather at random
     * @returns a weather at random
       */
    public Weather changeWeather(){
        x = rand.nextInt(3);
        
        weather=weather.nothing;
        if(x == 1 ){
            weather = weather.rain;
            
        
        }
        
        if(x == 2){
            weather = weather.fog;
            
            
        }
        
        if(x == 0){
            weather=weather.nothing;
            
        }
    
        return weather;
        
        
    }
    public String getWeather(){
        String type = " ";
        if(weather == weather.rain){
            type = "Raining";
        }
                 
        if(weather == weather.fog){
            type = "Foggy";
        }
        
        
        return type;
        
        
        
        
    }
    
    public Weather weather(){
        return weather;
    }
    
    
    
    
    
}
