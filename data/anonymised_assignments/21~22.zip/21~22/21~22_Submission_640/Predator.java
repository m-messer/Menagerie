
import java.util.List;
import java.util.Iterator;
import java.util.Random;

public abstract class Predator extends Animal
{
    // value of prey when eaten 
    public static final int Prey_FOOD_VALUE = 10;
    //probability they kill the prey
    private  double SUCCESSFUl_HUNT = 0.50;
    private static final Random rand = Randomizer.getRandom();
    
    
    
    public Predator(Field field, Location location)
    {
        // initialise instance variables
        super(field,location);
        ismale = revealGender();
        
        weather=weather.nothing;
        
    }
    
   
    
    
    /**
     * Look for rabbits adjacent to the current location.
     * Only the first live rabbit is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
         if(weather == weather.rain){
             //when it rains harder for them to catch prey
             SUCCESSFUl_HUNT = 0.40;
             
         }
        
         if(weather == weather.fog){
             //harder to catch prey because they cant see 
             SUCCESSFUl_HUNT = 0.3;
         }
        
        
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Prey) {
                Prey prey = (Prey) animal;
                if(prey.isAlive()&& rand.nextDouble() <= SUCCESSFUl_HUNT) { 
                    prey.setDead();
                    foodLevel = Prey_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
   
}
