/**
 * Enumeration class WeatherType - WeatherType is an enum where each
 * value represents a particular weather that the simulation environment
 * can possess.
 *
 * @version 2022.03.02
 *  
 */
public enum WeatherType
{    
    CLEAR(40, 70), RAIN(40, 70), FOG(40, 70);
    
    /**
     * The constructor for the WeatherType enum
     * @param minStep The minimum number of steps the weather can last for
     * @param maxStep The maximum number of steps the weather can last for
     */
    private WeatherType(int minStep, int maxStep) {
        
        this.minStep = minStep;
        this.maxStep = maxStep;
        
    }
    
    private int minStep;
    private int maxStep;
    
    /**
     * @return The minimum number of steps the weather can last for
     */
    public int getMinStep() {
        
        return minStep;
        
    }
    
    /**
     * @return The maximum number of steps the weather can last for
     */
    public int getMaxStep() {
        
        return maxStep;
        
    }
    
}
