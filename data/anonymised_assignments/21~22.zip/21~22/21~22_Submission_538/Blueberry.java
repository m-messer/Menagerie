import java.util.List;
import java.util.ArrayList;

/**
 * A class representing the behaviour and attributes of an Blueberry.
 *
 * @version 2022.03.02
 *  
 */

public class Blueberry extends Plant {

    private static final int MAX_AGE = 55;
    
    private static final double DISPERSE_PROBABILITY = 0.225;    
    
    public Blueberry(boolean randomAge, Field field, Location location, Environment environment) {
        
        super(field, location, environment);
        
        if (randomAge) {
            setAge(getRandom().nextInt(MAX_AGE));
            
        } else {
            setAge(0);
            
        }
        
    }
    
    public List<Location> getDispersableLocations() {
    
        // #-#-#
        // -#-#-   # - represents possible places for the plant to spread to
        // --@--   @ - represents the plant 
        // -#-#-   
        // #-#-#
        
        List<Location> potentialLocations = new ArrayList<>();
        
        if (getLocation() != null) {
            
            Location main = getLocation();
        
            int mainRow = main.getRow();
            int mainCol = main.getCol();
        
            for (int rowOffset = -2; rowOffset < 3; rowOffset++) {
                for (int colOffset = -2; colOffset < 3; colOffset++) {
                    
                    if (rowOffset == -2 || rowOffset == 2) {
                        if (colOffset == -2 || colOffset == 0 || colOffset == 2) {
                            
                            Location newLocation = new Location(mainRow + rowOffset, mainCol + colOffset, main.getLayer());
                            
                            if (validLocation(newLocation)) {
                                
                                // It is a valid position on the board and matches the pattern
                                                                
                                potentialLocations.add(newLocation);
                                
                            }
                            
                        }                    
                        
                    }
                    
                    if (rowOffset == -1 || rowOffset == 1) {
                        if (colOffset == -1 || colOffset == 1) {
                            
                            Location newLocation = new Location(mainRow + rowOffset, mainCol + colOffset, main.getLayer());
                            
                            if (validLocation(newLocation)) {
                                
                                // It is a valid position on the board and matches the pattern
                                                                
                                potentialLocations.add(newLocation);
                                
                            }
                            
                        }
                        
                    }
                    
                }
                
            }
                
        }

        return potentialLocations;
        
    }
    
    public void createSeed(List<Entity> newEntities, Location location, Environment environment) {
        
        Blueberry blueberry = new Blueberry(false, getField(), location, environment);
        newEntities.add(blueberry);
        
    }
    
    public int getMaxAge() {
        
        return MAX_AGE;
        
    }
    
    public double getDisperseProbability() {
        
        return DISPERSE_PROBABILITY;
        
    }

}
