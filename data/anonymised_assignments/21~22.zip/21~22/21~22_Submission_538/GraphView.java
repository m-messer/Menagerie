import java.awt.*;
import java.awt.geom.Path2D;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.swing.*;

/**
 * Provides a graphical display of a graph which measures and displays the population
 * of each species.
 *
 * @version 2022.03.02
 *  
 */

public class GraphView {

    private JFrame graphWindow;
    private Graph graph;
    private JPanel entityOptions;

    private JCheckBox blueberry;
    private JCheckBox bluejay;
    private JCheckBox corn;
    private JCheckBox eagle;
    private JCheckBox goat;
    private JCheckBox wolf;

    private Map<Class, JCheckBox> checkedEntities;
    
    /**
     * The constructor for the GraphView class,
     *  Creates a new window with with buttons and a JPanel component
     * @param entities The hashmap that associates entity classes with a colour
     */
    public GraphView(Map<Class, Color> entities) {

        graph = new Graph(entities);

        graphWindow = new JFrame();
        graphWindow.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        graphWindow.setTitle("Ecosystem Simulation - Graph");
        graphWindow.setLocationRelativeTo(null); // places the graph in the centre of the screen
        graphWindow.setLayout(new BorderLayout());
        graphWindow.add(graph, BorderLayout.CENTER);
        graphWindow.setSize(716,339);
        graphWindow.setResizable(false);
        graphWindow.setVisible(false);

        entityOptions = new JPanel(new GridLayout(6,1));

        graphWindow.add(entityOptions, BorderLayout.EAST);

        setCheckBoxes();

        checkedEntities = new HashMap<>();

        checkedEntities.put(Blueberry.class, blueberry);
        checkedEntities.put(BlueJay.class, bluejay);
        checkedEntities.put(Corn.class, corn);
        checkedEntities.put(Eagle.class, eagle);
        checkedEntities.put(Goat.class, goat);
        checkedEntities.put(Wolf.class, wolf);
        
    }

    /**
     * @return The classes of the checked entities associated with its corresponding checkbox through a hashmap
     */
    private Map<Class, JCheckBox> getClassCheckBoxes() {

        return checkedEntities;

    }
    
    /**
     * Creates checkboxes
     */
    private void setCheckBoxes() {

        
        blueberry = new JCheckBox("Blueberry");
        bluejay = new JCheckBox("BlueJay");
        corn = new JCheckBox("Corn");
        eagle = new JCheckBox("Eagle");
        goat = new JCheckBox("Goat");
        wolf= new JCheckBox("Wolf");

        blueberry.setFocusable(false);
        bluejay.setFocusable(false);
        corn.setFocusable(false);
        eagle.setFocusable(false);
        goat.setFocusable(false);
        wolf.setFocusable(false);

        entityOptions.add(blueberry);
        entityOptions.add(bluejay);
        entityOptions.add(corn);
        entityOptions.add(eagle);
        entityOptions.add(goat);
        entityOptions.add(wolf);

        blueberry.setSelected(true);
        bluejay.setSelected(true);
        corn.setSelected(true);
        eagle.setSelected(true);
        goat.setSelected(true);
        wolf.setSelected(true);

        // By default the buttons are shown to be checked

    }
    
    /**
     * Sets the graph window to be visible
     */
    public void setVisible() {

        graphWindow.setVisible(true);

    }
    
    /**
     * @return The graph object
     */
    public Graph getGraph() {

        return graph;

    }

    /**
     * JPanel component which draws the graph onto the JFrame
     */
    public class Graph extends JPanel {
    
        private HashMap<Class, ArrayList<Integer>> graphValues;
        private Map<Class, Color> entities;
        private int greatestValue;
        
        private Class[] checkBoxOrder = new Class[] {Blueberry.class, BlueJay.class, Corn.class, Eagle.class, Goat.class, Wolf.class};
        
        /**
         * The constructor for the graph class
         * @param entities The hashmap that associates entity classes with its colours
         */
        public Graph(Map<Class, Color> entities) {
    
            graphValues = new HashMap<>();
    
            this.entities = entities;
            
            for (Class key : entities.keySet()) {
    
                graphValues.put(key, new ArrayList<>());
                graphValues.get(key).add(0);
    
            }
    
        }
        
        /**
         * Updates the graph values, takes a parameter which associates the 
         * class with a counter, and these are appended to the list of values
         * per entity class.
         * @param entityCounts Class to Counter HashMap to get the counts of the entities in the simulation
         */ 
        public void updateGraphValues(HashMap<Class, Counter> entityCounts) {
    
            for (Class key : entityCounts.keySet()) {
    
                graphValues.get(key).add(entityCounts.get(key).getCount());
    
                if (graphValues.get(key).size() > 100) {
                    graphValues.get(key).remove(0);
    
                }
    
            }
    
            setGreatestGraphValue();
    
            repaint();
    
        }
    
        /**
         * Checks through each of the values within the ArrayList of entity
         * classes and returns the greatest value 
         */
        private void setGreatestGraphValue() {
    
            greatestValue = 0;
    
            for (Class key : getClassCheckBoxes().keySet()) {

                if (getClassCheckBoxes().get(key).isSelected()) {
                    for (int value : graphValues.get(key)) {
                        if (value > greatestValue) {
                            greatestValue = value;
        
                        }
        
                    }

                }
    
            }
    
        }
    
        /**
         * Drawing method to use the values in the ArrayLists and draw the lines
         * for the corresponding entity.
         */
        public void paintComponent(Graphics g) {
    
            super.paintComponent(g);
            
            Graphics2D g2 = (Graphics2D)g;
            
            // Backdrop 
            g2.setColor(Color.LIGHT_GRAY);
            g2.fillRect(0, 0, getWidth(), getHeight());
    
            // Graph Backdrop
            g2.setColor(Color.WHITE);
            g2.fillRect(25,25,500,250);
    
            g2.setColor(Color.BLACK);
            g2.drawString("" + (greatestValue + 50), 530, 30);
            g2.drawString("0", 530, 280);
            g2.drawString("step", 255, 290);
            g2.drawString("count", 530, 145);
    
            // Draws from bottom-left of Graph Box
            g2.translate(25, 275);

            
            for (Class key : getClassCheckBoxes().keySet()) {
    
                if (getClassCheckBoxes().get(key).isSelected()) {

                    int x = 0;
    
                    Path2D plot = new Path2D.Double();
                    plot.moveTo(x, -getGraphHeight(graphValues.get(key).get(0)));
        
                    for (int value : graphValues.get(key)) {
        
                        x += 4;
                        plot.lineTo(x, -getGraphHeight(value));
        
                        if (isLastValue(graphValues.get(key), value)) {
                            if (value != 0) {
                                g2.setColor(entities.get(key));
                                g2.drawString("" + value, 400, -getGraphHeight(value));
            
        
                            }
                        }
        
                    }
                    
                    // plot.closePath();
                    g2.setColor(entities.get(key));
                    g2.draw(plot);

                }
    
            }
    
            g2.translate(-25, -275);
    
            // Graph Border
            g2.setColor(Color.BLACK);
            g2.drawRect(25,25,500,250);
            
            g2.translate(600, 21);
            
            int yStep = 0;
            
            // Draw representation colours 
            for (Class key : checkBoxOrder) {
                
                g2.setColor(entities.get(key));
                g2.fillRect(0, yStep, 10, 10);
                
                yStep += 50;
                
            }
    
            g2.dispose();
    
        }
    
        /**
         * Takes the entity count and finds out how large that value is in
         * comparison to the greatest value, it is then multiplied by the graph
         * height. This scales the graph.
         */
        private int getGraphHeight(int entityCount) {
    
            if (entityCount != 0) {
    
                // System.out.println("im drawing up to :" + (int)Math.round((((double)(entityCount) / greatestValue)) * 250));
    
                return (int)Math.round((((double)(entityCount) / greatestValue)) * 240); // Height of the graph is 240 pixels // allows for white gap
    
            }
    
            return 0;
    
        }
    
        /**
         * Checks if the value which is given is the last value in the ArrayList 
         * which it came from.
         * @param values ArrayList<Integer> ArrayList of integers which represent the entity count
         * @param value the value which we are checking is the last in the ArrayList
         */    
        private boolean isLastValue(ArrayList<Integer> values, int value) {
    
            if (values.get(values.size() - 1) == value) {
                return true;
    
            }
    
            return false;
    
        }
    
    }

}
