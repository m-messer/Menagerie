import java.util.Random;

/**
 * The environment class handles the passage of time within the simulation and
 * the weather system which changes the weather every several steps.
 * 
 *
 * @version 2022.03.02
 *  
 */

public class Environment {
    
    private Random random = new Random();
    
    private Simulator simulator;
    
    private WeatherType currentWeather = WeatherType.CLEAR;
    private int weatherStep = 0;
    private int weatherLength;
    
    /**
     * The constructor for the environment class
     * @param simulator Reference to the simulator object
     */
    public Environment(Simulator simulator) {
        
        this.simulator = simulator;
        
    }
    
    /**
     * @return The current weather 
     */
    public WeatherType getCurrentWeather() {
        
        return currentWeather;
        
    }
    
    /**
     * Checks if the weatherType passed in is equal to the current weather
     * @param weatherType The weather type to check for
     * @return Whether the weather type passed in is equal to the current weather
     */
    public boolean isWeather(WeatherType weatherType) {
        
        return currentWeather == weatherType;
    
    }
    
    /**
     * Sets the weather length to a random integer where its possible values that it can take
     * are dependent on the weather type to be set to
     */
    private void setWeatherLength() {
        
        int range = currentWeather.getMaxStep() - currentWeather.getMinStep();
        weatherLength = currentWeather.getMinStep() + random.nextInt(range);
        
    }
    
    /**
     * Sets the current weather to a random weather type
     */
    private void setRandomWeather() {
        
        int randomIndex = random.nextInt(WeatherType.values().length);
        currentWeather = WeatherType.values()[randomIndex];
        
    }
    
    /**
     * Increments the weather step and triggers the weather to be changed once its value reaches the weather length
     */
    public void incrementWeatherStep() {
        
        weatherStep += 1;
        
        if (weatherStep >= weatherLength) {
            weatherStep = 0;
            setRandomWeather();
            setWeatherLength();
            
        }
        
    }
    
    /**
     * Gets the current hour which is derived from the current step of the simulation
     * @return The current hour
     */
    public int getHour() {
        
        return simulator.getStep() % 24;
        
    }
    
    /**
     * @return Whether it is day time
     */
    public boolean isDayTime() {
        
        return getHour() < 12;
        
    }
    
    /**
     * @return The string value to display that represents the simulators time
     */
    public String isDayTimeString() {
        
        if (getHour() < 12) {
            return "(Day)";
            
        }
        
        return "(Night)";
        
    }
    
    public String getWeatherString() {
        
        switch (getCurrentWeather()) {
            
            case RAIN: return "Rain";
            
            case FOG: return "Fog";
            
            case CLEAR: return "Clear";
            
            default: return "";
            
        }
        
    }
    
}
