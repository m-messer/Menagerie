import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.Point;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Button;
import java.util.stream.Collectors;

/**
 * A class handling user interactions through mouse controls.
 * Doc: https://docs.oracle.com/javase/tutorial/uiswing/events/mouselistener.html
 *
 * @version 2022.02.13
 */
public class EventHandler implements MouseListener, ActionListener
{
    /*
     * Class variables
     */
    
    private static final Color SELECT_BUTTON_COLOR = Color.RED;
    
    /*
     * Attributes
     */
    
    // Represents the simulation the mouse handler is managing.
    private Simulator simulation;
    // Users' currently selected species.
    private Species selectedSpecies;
    // User's currently selected button.
    private Button currentButtonSelected;
    
    /**
     * Create a new mouse handler.
     * 
     * @param simulation The simulation that the listener is currently handling.
     */
    public EventHandler(Simulator simulation)
    {
        this.simulation = simulation;
    }
    
    /*
     * Overridden methods.
     */
    
    /**
     * Button pressed event handler.
     * 
     * @param e Button event object.
     */
    public void actionPerformed(ActionEvent e) 
    {
        // .getSource() returns object, so cast is required.
        // Docs: https://docs.oracle.com/javase/8/docs/api/java/util/EventObject.html?is-external=true#getSource--
        selectButton((Button)e.getSource());
    }
    
    /**
     * Represents the mouse being pressed.
     * 
     * @param e Mouse event object.
     */
    public void mousePressed(MouseEvent e) 
    {
        if (selectedSpecies != null)
        {
            // Location to create entity.
            Location location = getLocationPressed(e);
            Field field = simulation.getField();
            
            createEntity(location, field);
        }
    }
    
    /**
     * Represents the mouse press being released.
     * 
     * @param e Mouse event object.
     */
    public void mouseReleased(MouseEvent e) { }

    /**
     * Represents the mouse entered event occuring.
     * 
     * @param e Mouse event object.
     */
    public void mouseEntered(MouseEvent e) { }

    /**
     * Represents the mouse exit event occuring.
     * 
     * @param e Mouse event object.
     */
    public void mouseExited(MouseEvent e) { }

    /**
     * Represents the mouse click event occuring.
     * 
     * @param e Mouse event object.
     */
    public void mouseClicked(MouseEvent e) { }
    
    /*
     * Private methods
     */
    
    /**
     * Create an entity to add to the field and add it to the simulations pending entities.
     * 
     * @param location The location of the entity to be added to the simulation.
     * @param field The field of the entity that is to be added.
     */
    private void createEntity(Location location, Field field)
    {
        try
        {
            if (field.getObjectAt(location) == null)
            {
                if (selectedSpecies instanceof AnimalSpecies)
                {
                    // Create new animal.
                    Animal newAnimal = new Animal(null, field, location, (AnimalSpecies)selectedSpecies);
                    simulation.addPendingEntity(newAnimal);
                }
                else
                {
                    // Create new plant.
                    Plant newPlant = new Plant(field, location, (PlantSpecies)selectedSpecies);
                    simulation.addPendingEntity(newPlant);
                }
            }
        }
        catch (Exception error) 
        {
            System.out.println("System failed to add entity to field. Error: " + error);
        }      
    }
    
    /**
     * Select the button that the user has clicked.
     * 
     * @param button The button that the user has pressed.
     */
    private void selectButton(Button button)
    {
        changeButtonColor(currentButtonSelected, Color.BLACK);
        
        // Lamda function retrieve species with the associated button name.
        selectedSpecies = simulation.getSpecies().stream()
                        .filter(s -> s.getName().equals(button.getLabel()))
                        .collect(Collectors.toList()).get(0);
                  
        // Change button color.
        changeButtonColor(button, SELECT_BUTTON_COLOR);
        
        currentButtonSelected = button;
    }
    
    /**
     * Change the background color of the button.
     * 
     * @param button The button to undergo a color change.
     * @param color The color object that the button background color will be set to.
     */
    private void changeButtonColor(Button button, Color color)
    {
        if (button != null)
        {
            button.setBackground(color);
            button.repaint();
        }
    }
    
    /**
     * Get the location on the field that the user pressed.
     * 
     * @param e The mouse event object which contains the unscaled coords.
     * @return The location on the field that the user pressed.
     */
    private Location getLocationPressed(MouseEvent e)
    {
        Point pointClicked = simulation.getView().getVirtualCord(e.getX(), e.getY());
        
        // Cordinates that reflect the field object, not the screen click.
        int virtualX = (int) pointClicked.getX();
        int virtualY = (int) pointClicked.getY();
        
        // Field locations are col first, then row.
        return new Location(virtualY, virtualX);
    }
}
