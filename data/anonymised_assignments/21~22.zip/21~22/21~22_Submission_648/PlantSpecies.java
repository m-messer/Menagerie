/**
 * A model of a plant species.
 *
 * @version 2022.02.11
 */
public class PlantSpecies extends Species
{
    // How much the a plant within this species grows in favourable weather.
    private int growthFactor;
    // The max height the plant species can grow to.
    private int maxHeight;

    /**
     * Create a new plant species.
     * 
     * @param name The name of the plant species.
     * @param foodValue The food value for entities that may eat this plant species.
     * @param growthFactor The height grown with each favourable weather day.
     * @param maxHeight The maximum height the plant species can grow to.
     */
    public PlantSpecies(String name, int foodValue, double creationProbability, int growthFactor, int maxHeight)
    {
        super(name, foodValue, creationProbability);
        
        this.growthFactor = growthFactor;
        this.maxHeight = maxHeight;
    }
    
    /*
     * Getters
     */
    
    /**
     * @return How much this plant species grows per step.
     */
    public int getGrowthFactor() { return growthFactor; }
    
    /**
     * @return The max height of a member of the plant species.
     */
    public int getMaxHeight() { return maxHeight; }

}
