import java.util.List;
import java.util.Random;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.Comparator;

/**
 * A class representing shared characteristics of entities.
 * An entity is any 'thing' that is considered alive.
 * e.g. Animal, Plant or Disease.
 *
 * @version 2022.02.11
 */
public abstract class Entity
{
    // Whether the entity is alive or not.
    private boolean alive;
    // The entity's field.
    private Field field;
    // The entity's position in the field.
    private Location location;

    /**
     * Create a new entity at a location in the field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Entity(Field field, Location location)
    {
        // Set defaults
        alive = true;
        
        // Set parameters
        this.field = field;
        setLocation(location);
    }
    
    /*
     * Abstract methods
     */

    /**
     * Make this entity act - that is: make it do
     * whatever it wants/needs to do.
     * 
     * @param newEntities A list to receive newly created entities.
     */
    abstract void act(List<Entity> newEntities, Clock clock);
    
    /**
     * This entity has been eaten by another entity.
     * 
     * @return Whether the entity has been successfully eaten.
     */
    abstract Boolean beEaten();
    
    /**
     * Returns the species that the entity belongs to.
     * 
     * @return The species that the entity belongs to.
     */
    abstract Species getSpecies();
    
    /*
     * Protected methods
     * Scope extends to subclasses.
     */
    
    /**
     * Returns a list of Entities that occupy locations adjacent to to this entity.
     * 
     * @return  A list of entities that are adjacent.
     */
    protected List<Entity> getAdjacentEntities()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        
        // Stores the list of all entities that are in adjacent locations.
        List<Entity> adjacentEntities = new ArrayList<>();
        
        while (it.hasNext())
        {
            Location where = it.next();
            Entity entity = (Entity)field.getObjectAt(where);
            
            // Only want non-null objects within returned list.
            if (entity != null && entity.isAlive())
            {
                adjacentEntities.add(entity);
            }
        }
        
        return adjacentEntities;
    }
    
    /**
     * Returns a list of animals that are adjacent to this entity.
     * 
     * @return A list of animals adjacent to this entity
     */
    protected List<Animal> getAdjacentAnimals()
    {
        return getAdjacentEntities().stream()
                            .filter(entity -> entity instanceof Animal)
                            .map(entity -> (Animal)entity)
                            .collect(Collectors.toList());
    }
    
    /*
     * Getters
     */
    
    /**
     * Return the entity's location.
     * @return The entity's location.
     */
    public Location getLocation()
    {
        return location;
    }
    
    /**
     * Return the entity's field.
     * @return The entity's field.
     */
    public Field getField()
    {
        return field;
    }
    
    /**
     * Check whether the entity is alive or not.
     * @return true if the entity is still alive.
     */
    public boolean isAlive()
    {
        return alive;
    }
    
    /*
     * Setters
     */
    
    /**
     * Place the entity at the new location in the given field.
     * @param newLocation The entity's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) 
        {
            field.clear(location);
        }
        
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Indicate that the entity is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {;
        alive = false;
        if(location != null) 
        {
            field.clear(location);
            location = null;
            field = null;
        }
    }
}
