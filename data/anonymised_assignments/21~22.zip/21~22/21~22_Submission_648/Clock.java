/**
 * A class representing time in the simulation.
 *
 * @version 2022.02.13
 */
public class Clock
{
    /*
     * Class variables
     */
    
    // How many ticks represents an 'hour'.
    private static int TICK_RATIO = 1;
    // How many ticks between weather updates.
    private static int WEATHER_INTERVAL = 6;
    // The hour at which sunset occurs
    private static final int SUNSET_HOUR = 19;
    // The hour at which sunrise occurs
    private static final int SUNRISE_HOUR = 7;
    
    /*
     * Attributes
     */
    
    // Stores how many ticks have occured on this clock.
    private int ticks;
    // Manages the weather in accordance with time.
    private WeatherManager weatherManager;

    /**
     * Create a new clock.
     */
    public Clock()
    {
        ticks = 0;
        weatherManager = new WeatherManager();
    }

    /*
     * Public methods
     */
    
    /**
     * Move clock forward by one tick.
     */
    public void tick()
    {
        ticks++;
        
        // Update weather every inteval specified in class variables.
        if (ticks % WEATHER_INTERVAL == 0)
        {
            weatherManager.update(isDaytime());
        }
    }
    
    /**
     * Gets the current state of the clock.
     * 
     * @param time Whether a time string is to be included in the status.
     * @param abbrv Whether an AM/PM abbreviation is to be showed after time.
     * @param lightLevel Whether if the sun is up is to be shown in the status.
     * @param day Whether the day counter is to be showed in status.
     * @param weather Whether or not to show current weather in status.
     * @return The clock's current status.
     */
    public String getStatus(Boolean time, Boolean abbrv, Boolean lightLevel, Boolean day, Boolean weather)
    {
        String timeStatus = "";
        
        // e.g. Time: 11:00 AM
        if (time)
        {
            timeStatus += "Time: " + getTimeString(abbrv) + " ";
        }
        
        // e.g. (Day)
        if (lightLevel)
        {
            timeStatus += getLightString() + " ";
        }
        
        // e.g. Day: 44
        if (day)
        {
            timeStatus += "Day: " + getDay() + " ";
        }
        
        // e.g. Weather: Sunny
        if (weather)
        {
            timeStatus += "Weather: " + weatherManager.getCurrentWeather() + " ";
        }
        
        return timeStatus.trim();
    }
    
    /**
     * Reset the clock.
     */
    public void reset()
    {
        ticks = 0;
    }
    
    /**
     * Checks to see if it is day time or not.
     * 
     * @return Whether it is day time or not.
     */
    public Boolean isDaytime()
    {
        if (getHour() > SUNRISE_HOUR && getHour() < SUNSET_HOUR)
        {
            return true;
        }
        return false;
    }
    
    /*
     * Getters
     */
    
    /**
     * @return The weather manager associated with this timeline.
     */
    public WeatherManager getWeatherManager()
    {
        return weatherManager;
    }
    
    /*
     * Private methods
     */
    
    /**
     * Returns the current clock time, depending on params, displays AM or PM after.
     * 
     * @param abbrv Whether an 'AM' or 'PM' abbreviation is to be added to end of string.
     * @return The current time in a string format.
     */
    private String getTimeString(Boolean abbrv)
    {
        String timeString = "";
        int hour = getHour();
        
        // Pad time to 24hr format.
        if (String.valueOf(hour).length() == 1)
        {
            timeString += "0" + hour + ":00";
        }
        else
        {
            timeString += hour + ":00";
        }
        
        if (abbrv)
        {
            return timeString + getTimeAbbreviation();
        }
        else
        {
            return timeString;
        }
    }
    
    /**
     * Decide if AM or PM.
     * 
     * @return Either "AM" or "PM", depending on the time of day.
     */
    private String getTimeAbbreviation()
    {
        
        if (getHour() < 12) 
        {
            return "AM";
        }
        else
        {
            return "PM";
        }
    }
    
    /**
     * Returns a string that indicates whether the sun is up or not.
     * 
     * @return A string illistrating whether the sun is up.
     */
    private String getLightString()
    {
        if (isDaytime())
        {
            return "(Day)";
        }
        else
        {
            return "(Night)";
        }
    }
    
    /**
     * @return The current hour represented by the clock.
     */
    private int getHour()
    {
        return (ticks / TICK_RATIO) % 24;
    }
    
    /**
     * @return How many days have elapsed from ticks.
     */
    private int getDay()
    {
        return ticks / (TICK_RATIO * 24);
    }
}
