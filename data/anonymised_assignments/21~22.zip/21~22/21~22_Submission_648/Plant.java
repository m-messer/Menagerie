import java.util.List;

/**
 * A class representing shared characteristics of plants.
 *
 * @version 2022.02.13
 */
public class Plant extends Entity
{
    /*
     * Class variables
     */
    
    // The height that a plant cannot go lower than.
    private static final int MIN_HEIGHT = 1;
    // The chance the plant will die on a day without rain.
    private static final double DROUGHT_DEATH_PROB = 0.001;

    /*
     * Attributes. 
     * Things that don't change within a plant's lifespan.
     */
    
    // The species that the plant belongs to.
    private PlantSpecies species;
    
    /*
     * Dynamic attributes
     */
    
    // The plant's current height.
    private int height;

    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param species The species that the plant belongs to.
     */
    public Plant(Field field, Location location, PlantSpecies species)
    {
        super(field, location);
        
        this.species = species;
        this.height = species.getMaxHeight();
    }
    
    /*
     * Overriden methods
     */
    
    /**
     * Make this plant act - that is: make it do
     * whatever it wants/needs to do.
     * @param newPlants A list to receive newly created plants.
     */
    public void act(List<Entity> newPlants, Clock clock)
    {
        if (isAlive())
        {
            if (clock.getWeatherManager().getCurrentWeather() != "Raining")
            {
                // If it isn't raining, there is a chance that plans may die from drought.
                if (Randomizer.getRandom().nextDouble() <= DROUGHT_DEATH_PROB)
                {
                    setDead();
                }
                else if (canGrow(clock))
                {
                    grow();
                }
            }
            
        }
    }
    
    /**
     * This entity has been eaten by another entity.
     * 
     * @return Whether the plant has been successfully eaten.
     */
    public Boolean beEaten()
    {
        if (canBeEaten())
        {
            height -= species.getFoodValue();
            
            if (height < MIN_HEIGHT)
            {
                setDead();
            }

            return true;
        }
        
        return false;
    }

    /**
     * @return The species of this plant.
     */
    public PlantSpecies getSpecies()
    {
        return species;
    }
    
    /*
     * Public methods
     */
    
    /**
     * Checks to see if the plant is tall enough for an entity to eat it.
     * 
     * @return Whether the plant is tall enough to be eaten.
     */
    public Boolean canBeEaten()
    {
        return height >= MIN_HEIGHT;
    }
    
    /*
     * Private methods
     */
    
    /**
     * Increases the height of the plant if possible.
     */
    private void grow()
    {
        height += species.getGrowthFactor();
    
        if (height > species.getMaxHeight())
        {
            height = species.getMaxHeight();
        }
    }
    
    /**
     * Checks to see if the current weather is favourable for the plant growth.
     * 
     * @param clock The simulations clock.
     * @return Whether the plant can grow at this time.
     */
    private Boolean canGrow(Clock clock)
    {
        return clock.isDaytime();
    }

}
