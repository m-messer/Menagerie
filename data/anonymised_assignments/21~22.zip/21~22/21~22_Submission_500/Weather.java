import java.util.Random;

/**
 * Provide the state of the weather.
 * This includes changing weather events, storing the state of the weather,
 * and providing access to it.
 *
 * @version 2022.03.02
 */
public class Weather
{
    // A random number generator for providing random locations.
    private static final Random rand = Randomizer.getRandom();
    
    // The number of simulation steps, during which a weather event will be active
    private static final int MAX_EVENT_LENGTH = 24;
    
    // Possibility of cloud
    private static final double CLOUD_PROBABILITY = 0.02;
    // Possibility of rain
    private static final double RAIN_PROBABILITY = 0.02;
    
    // Whether a weather event is active
    private boolean cloudy;
    private boolean rainy;
    
    // Determines how long an event should last
    private int eventLength;
    
    /**
     * Constructor for objects of class Weather
     * Set weather to its normal state.
     */
    public Weather()
    {
        resetWeather();
    }
    
    /**
     * Sets weather to its normal state
     */
    public void resetWeather()
    {
        cloudy = false;
        rainy = false;
        eventLength = 0;
    }
    
    /**
     * Updates weather by changing event states based on their respective probabilities.
     * Returns weather to its normal state if an event is over.
     */
    public void simulateWeather()
    {
        if(!cloudy && rand.nextDouble() <= CLOUD_PROBABILITY) {
            cloudy = true;
        } else if(!rainy && rand.nextDouble() <= RAIN_PROBABILITY) {
            rainy = true;
        }
        
        if(cloudy || rainy) {
            eventLength++;
        }
        
        if(eventLength > MAX_EVENT_LENGTH) {
            resetWeather();
        }
    }
    
    /**
     * Return an event state
     * @return boolean Whether "cloudy" event is ongoing
     */
    public boolean isCloudy()
    {
        return cloudy;
    }
    
    /**
     * Return an event state
     * @return boolean Whether "rainy" event is ongoing
     */
    public boolean isRainy()
    {
        return rainy;
    }
    
    /**
     * Return when the event is going to be over
     * @return int The remaining steps until the end of a weather event
     */
    public int getEventLength()
    {
        return eventLength;
    }
}
