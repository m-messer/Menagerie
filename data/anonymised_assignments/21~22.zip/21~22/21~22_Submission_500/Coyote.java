import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a coyote.
 * Coyotes age, move, breed, check their environment, eat hare,
 * spread infection, get infected, and die.
 * 
 * @version 2022.03.02
 */
public class Coyote extends Animal
{
    // Characteristics shared by all coyotes (class variables).
    
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // The age at which a coyote can start to breed.
    private static final int BREEDING_AGE = 6;
    // The age to which a coyote can live.
    private static final int MAX_AGE = 120;
    // The likelihood of a coyote breeding.
    private static final double BREEDING_PROBABILITY = 0.25;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a prey. In effect, this is the
    // number of steps a coyote can go before it has to eat again.
    private static final int HARE_FOOD_VALUE = 12;
    // Chance of spreading infection
    private static final double INFECTION_CHANCE = 0.002;
    // Chance of contacting infection
    private static final double INFECTION_CONTACT_CHANCE = 0.002;
    
    // Individual characteristics (instance fields).
    // The coyote's age.
    private int age;
    // The coyote's food level, which is increased by eating coyotes.
    private int foodLevel;

    /**
     * Create a coyote. A coyote can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the coyote will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Coyote(boolean randomAge, Field field, Location location, boolean infectionContact)
    {
        super(field, location, infectionContact);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(HARE_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = HARE_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the coyote does most of the time: it hunts for
     * coyotes. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newCoyotes A list to return newly born coyotes.
     */
    public void act(List<Actor> newCoyotes)
    {
        incrementAge();
        
        // Only increment hunger at daytime or if infected
        if(checkDay() || isInfected()) {
            incrementHunger();
        } else {
            checkDead();
        }
        
        if(isAlive()) {
            if(checkDay()){
                // If the hare is mature, female and has a male mating partner nearby, it will reproduce
                if(canBreed() && findMate()){
                    giveBirth(newCoyotes);       
                }
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());  // check for instance of grass
                }
                // Se if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            } else {
                checkDead();
            }
        }
        
        // Get infected if contacted by the infection
        if(isContacted() && rand.nextDouble() <= INFECTION_CHANCE) {
            infect();
        }
    }

    /**
     * Increase the age.
     * This could result in the hare's death.
     */
    private void incrementAge()
    {
        age++;
        checkDead();
    }
    
    /**
     * Make this fox more hungry. This could result in the fox's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        checkDead();
    }
    
    /**
     * Make this fox more hungry. This could result in the fox's death.
     */
    private void checkDead()
    {
        if(age > MAX_AGE || foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for coyotes adjacent to the current location.
     * Only the first live coyote is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Hare) {
                Hare hare = (Hare) animal;
                if(hare.isAlive()) { 
                    hare.setDead();
                    foodLevel = HARE_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Look for coyotes adjacent to the current location.
     * Only the first male coyote is chosen as partner. Infection can be spread.
     * @return Whether a suitable mating partner exists
     */
    private boolean findMate()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Coyote) {
                Coyote coyote = (Coyote) animal;
                // Spread the infection to the mating partner depending on the probability of spreading the infection
                if(isInfected() && rand.nextDouble() <= INFECTION_CONTACT_CHANCE){
                    coyote.contactInfection();
                }
                if(!coyote.isFemale()) { 
                    return true;
                }
            }
        }
        return false;
    }
    
    /**
     * Check whether or not this coyote is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newCoyotes A list to return newly born coyotes.
     */
    private void giveBirth(List<Actor> newCoyotes)
    {
        // New coyotes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Coyote young = new Coyote(false, field, loc, false);
            newCoyotes.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * A coyote can breed if it has reached the breeding age and is female.
     * @return true if the coyote can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return (age >= BREEDING_AGE && this.isFemale());
    }
}
