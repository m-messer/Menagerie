import java.util.List;
import java.util.Random;

/**
 * A simple model of a chicken.
 * chickens age, move, eat food, breed and die.
 *  
 */
public class Chicken extends Animal
{
    // Characteristics shared by all chickens (class variables).

    // The age at which a chicken can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a chicken can live.
    private static final int MAX_AGE = 40;
    // The likelihood of a chicken breeding.
    private static final double BREEDING_PROBABILITY = 0.3;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // Value of food (will add plant/vegetable later).
    //Steps before chicken can take it has to eat again
    private static final int FOOD_VALUE = 9;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).
    // The chicken's age.
    private int age;
    // The chicken's food level, which is increased by eating food.
    private int foodLevel;

    /**
     * Create a new chicken. A chicken may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the chicken will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Chicken(boolean randomAge, Field field, Location location)
    {
        super(field, location, rand.nextBoolean());
        //randomise the age.
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(FOOD_VALUE);
            if (rand.nextDouble() < 0.05) {setDiseased();}
        }
        else {
            age = 0;
            foodLevel = FOOD_VALUE;
        }
    }

    /**
     * In the simulation, chickens can become infected, and thus need to act
     * differently in order to maintain this behaviour
     * @param newAnimals A list to receive newly born animals.
     */
    @Override
    public void act(List<Creature> newAnimals) {
        if (isAlive()) {
            //Chance to be diseased
            if (rand.nextDouble() < 0.0001)
            {
                setDiseased();
            }
        }
        super.act(newAnimals);
    }

    /**
     * Increase the age.
     * This could result in the chicken's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this chicken more hungry. This could result in the chicken's death.
     */
    protected void incrementHunger()
    {

    }

    /**
     * Look for food adjacent to the current location.
     * Only the first plant is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.getFreeAdjacentLocations(getLocation());

        return null;
    }

    /**
     * Check whether or not this chicken is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newChickens A list to return newly born chickens.
     */
    protected void giveBirth(List<Creature> newChickens)
    {
        // New chickens are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Chicken young = new Chicken(false, field, loc);
            newChickens.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A chicken can breed if it is  of breeding age and
     * has an adjacent opposite gender mate who is also of breeding age.
     * @return true if the chicken can breed, false otherwise.
     */
    private boolean canBreed()
    {
        if(age < BREEDING_AGE) {return false;}
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for (Location location : adjacent) {
            Object animal = field.getObjectAt(location);
            if (animal instanceof Chicken) {
                Chicken mate = (Chicken) animal;
                if (isMale() != mate.isMale() && mate.age >= BREEDING_AGE) {
                    return true;
                }
            }
        }
        return false;
    }

}
