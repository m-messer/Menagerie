import java.util.List;
import java.util.Random;

/**
 * A simple model of a snail
 * Snails age, move, breed and die.
 *  
 */
public class Snail extends Animal{

    // Characteristics shared by all mice (class variables).

    // The age at which a snail can start to breed.
    private static final int BREEDING_AGE = 5;
    // The likelihood of a snail breeding.
    private static final double BREEDING_PROBABILITY = 0.09;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // Individual characteristics (instance fields).

    // The snail's age
    private int age;

    // The snail's hunger level
    private int snailHunger = 0;

    /**
     * Create a new snail. A snail may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the snail will have a random age.
     * @param field The field occupied.
     * @param location The location within the field.
     */
    public Snail(boolean randomAge, Field field, Location location) {
        super(field, location, rand.nextBoolean());
        age = 0;
        if (randomAge) {
            age = rand.nextInt(BREEDING_AGE);
        }
    }

    /**
     * Snails are designed to be an obstacle to other animals.
     * They do not eat and are not eaten by predators. They can
     * move if there is empty space, otherwise they will remain stationary.
     * @param newAnimals A list to receive newly born animals.
     */
    @Override
    public void act(List<Creature> newAnimals) {
        incrementAge();

        if (isAlive()) {

            Location newLocation = getField().freeAdjacentLocation(getLocation());
            if (newLocation != null) {
                setLocation(newLocation);
            }
            if (rand.nextDouble() < BREEDING_PROBABILITY && age >= BREEDING_AGE) {
                giveBirth(newAnimals);
            }
            if (snailHunger>8) {
                setDead();
            }
        }
    }

    /**
     * Ages the snail by 1
     */
    protected void incrementAge() {
        age++;
    }

    /**
     * Does nothing in the case of a snail
     */
    protected void incrementHunger() {}

    /**
     * Eat nearly plant
     * @return where plant is found, or null if it wasn't
     */
    protected Location findFood() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for (Location where : adjacent) {
            Object creature = field.getObjectAt(where);
            if (creature instanceof Plant) {
                Plant plant = (Plant) creature;
                if (plant.isAlive()) {
                    plant.beEaten();
                    return where;
                }
                else
                {
                    snailHunger++;
                }
            }
        }
        return null;
    }

    /**
     * A snail can give birth without having to be in contact with another mate
     * However, it will only give birth to one new snail, and will die afterwards
     * @param newSnails List with references to new snails
     */
    protected void giveBirth(List<Creature> newSnails) {
        // Snails can give birth without a partner
        Field field = getField();
        Location free = field.freeAdjacentLocation(getLocation());

        if (free != null) {
            Snail young = new Snail(false, field, free);
            newSnails.add(young);
            setDead();
        }
    }

}
