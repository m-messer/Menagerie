/**
 * Parent class of Animal and Plant
 *  
 */

public abstract class Creature {

}
