import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 * 
 */
public abstract class Animal extends Creature
{
    // Whether the animal is alive or not.
    private boolean alive;
    //whether the animal is nocturnal
    private boolean nocturnal;
    //whether the animal is always awake
    private boolean diurnal;
    //whether the animal is diseased
    private boolean diseased;

    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // Whether the animal is male, otherwise it is implied to be female
    private final boolean isMale;

    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a new animal at location in field.
     *
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location, boolean isMale)
    {
        alive = true;

        nocturnal = false;
        diurnal = false;
        diseased = false;

        this.isMale = isMale;

        this.field = field;
        setLocation(location);
    }

    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    public void act(List<Creature> newAnimals)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            diseaseAct();
        }

        if(isAlive()) {

            giveBirth(newAnimals);
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) {
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }

    /**
     * Checks whether the animal recovers, dies or continues living with the
     * disease, and if it should infect another animal.
     */
    private void diseaseAct()
    {
        if(isDiseased()){
            tryInfect();
            int roll = rand.nextInt(5);
            //it recovers
            if(roll == 0) {
                setRecover();
            }
            //or dies
            else if( (roll == 1) ) {
                setDead();
            }
            //or continues living
        }
    }

    /**
     * Search for a nearby animal to infect.
     * Disease spread probability can be altered to control the rate at which animals die
     */
    private void tryInfect()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        for (Location where : adjacent) {
            Object animal = field.getObjectAt(where);
            if (animal instanceof Animal) {
                Animal subject = (Animal) animal;
                if ((!subject.isDiseased()) && (rand.nextDouble() < 0.1)) {
                    subject.setDiseased();
                }
            }
        }
    }

    /**
     * Implements how the animal should age each step
     */
    protected abstract void incrementAge();

    /**
     * Implements how the animal's hunger is affected each step
     */
    protected abstract void incrementHunger();

    /**
     * Implements the way in which the animal checks for food
     * @return the location of a valid food source, otherwise null
     */
    protected abstract Location findFood();

    /**
     * Implements how the animal should give birth to offspring
     * @param newAnimals a list of the new animals created
     */
    protected abstract void giveBirth(List<Creature> newAnimals);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Check whether animal is nocturnal
     * @return true if animal is nocturnal
     */
    protected boolean isNocturnal()
    {
        return nocturnal;
    }

    /**
     * Check whether animal doesn't sleep
     * @return true if animal doesn't sleep
     */
    /**
     * Check whether animal doesn't sleep
     * @return true if animal doesn't sleep
     */
    protected boolean isDiurnal()
    {
        return diurnal;
    }

    /**
     * Check whether animal is male
     * @return true if animal is male
     */
    protected boolean isMale() {return isMale;}

    /**
     * Check whether animal is diseased
     * @return true if animal is diseased
     */
    protected boolean isDiseased()
    {
        return diseased;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    protected void setDiseased()
    {
        diseased = true;
    }

    protected void setRecover()
    {
        diseased = false;
    }

    /**
     * Set the animal as nocturnal
     */
    protected void setNocturnal()
    {
        nocturnal = true;
    }

    /**
     * Set the animal as diurnal
     */
    protected void setDiurnal()
    {
        diurnal = true;

    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
}
