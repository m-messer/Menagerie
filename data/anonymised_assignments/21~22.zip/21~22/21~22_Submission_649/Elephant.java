import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.ArrayList;

/**
 * A simple model of a elephant.
 * Elephants age, move, breed, eat grass and die.
 *
 * @version 2016.02.29 (2)
 */
public class Elephant extends Animal
{
    // Characteristics shared by all elephants (class variables).

    // The age at which a elephant can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a elephant can live but this can be reduced if a diseases is caught.
    private int max_age = 48;
    // The likelihood of a elephant breeding.
    private static final double BREEDING_PROBABILITY = 0.69;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 5;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // A shared random number generator to control disease spread.
    private static final Random randDisease = Randomizer.getRandom();
    // The time the elephants wake up
    private final int wakeUp = 2;
    // The time the elephants go to sleep
    private final int bedTime = 8; 

    // Individual characteristics (instance fields).

    // The elephant's age.
    private int age;

    /**
     * Create a new elephant. A elephant may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the elephant will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Elephant(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(max_age);
        }
    }

    /**
     * This is what the elephant does most of the time - it runs
     * around. Sometimes it will breed or die of old age.
     * @param newElephants A list to return newly born elephants.
     */
    public void act(List<Animal> newElephants)
    {
        incrementAge();

        if(isAlive()) {
            if (checkDisease()) {
                diseaseAffects();
                spread();
            }
            if ((getTime() >= wakeUp && getTime() < bedTime)  && isSun()){
                giveBirth(newElephants);            
                // Try to move into a free location.
                Location newLocation = getField().freeAdjacentLocation(getLocation());
                if(newLocation != null) {
                    setLocation(newLocation);
                }
            }
            else{
                Location sameLocation = getLocation();
                // Stay in the same location
                setLocation(sameLocation);
            }
        }

        else {
            // Overcrowding.
            setDead();
        }
    }

    /**
     * Increase the age.
     * This could result in the elephant's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > max_age) {
            setDead();
        }
    }

    /**
     * Check whether or not this elephant is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newElephants A list to return newly born elephants.
     */
    private void giveBirth(List<Animal> newElephants)
    {
        // New elephants are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Elephant young = new Elephant(false, field, loc);
            newElephants.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if (mateNear() && canBreed() && (rand.nextDouble() <= BREEDING_PROBABILITY)) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A elephant can breed if it has reached the breeding age.
     * @return true if the elephant can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }

    /**
     * Check if the animal in the adjecent location is the opposite gender and the same animal
     * If they are the opposite gender and the same animal then allow them to breed
     * @return true if they are allowed to breed
     */
    private boolean mateNear() 
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        boolean mateFound = false;
        while (!mateFound && it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Elephant){
                if (((Elephant) animal).checkFemale() != this.checkFemale()) {
                    mateFound = true;
                }
            }
        }
        return mateFound;
    }

    /**
     * Check if the elephant is a baby
     * This is when elephants are under the age of 40     
     * @return true if the elephant is a baby
     */
    public boolean isBaby() 
    {
        return (age < 40);
    }
    
    /**
     * When the elephant contracts the disease it will lower its life span
     * Every elephant is affected differently by the disease
     * 
     */
    private void diseaseAffects(){
        max_age = rand.nextInt(max_age - age + 1) + age;
    }

    /**
     * When an elephant has a disease then its neighbouring elephants
     * also have a chance of catching the disease
     */
    private void spread() 
    {
        List <Animal> neighbours = new ArrayList <>();
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Elephant && randDisease.nextDouble() <= spreadProbability()) {
                ((Elephant) animal).diseaseAffects();
            }
        }
    }
}
