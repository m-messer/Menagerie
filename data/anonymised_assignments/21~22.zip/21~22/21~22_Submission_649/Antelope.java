import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.ArrayList;

/**
 * A simple model of a antelope.
 * Antelopes age, move, breed, eat grass and die.
 *
 * @version 2016.02.29 (2)
 */
public class Antelope extends Animal
{
    // Characteristics shared by all antelopes (class variables).

    // The age at which a antelope can start to breed.
    private static final int BREEDING_AGE = 11;
    // The age to which a antelope can live but this can be reduced if a diseases is caught.
    private int max_age = 67;
    // The likelihood of a antelope breeding.
    private static final double BREEDING_PROBABILITY = 0.73;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 9;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // A shared random number generator to control disease spread.
    private static final Random randDisease = Randomizer.getRandom();
    // The time the antelopes wake up
    private final int wakeUp = 2;
    // The time the antelopes go to sleep
    private final int bedTime = 11; 

    // Individual characteristics (instance fields).

    // The antelope's age.
    private int age;

    /**
     * Create a new antelope. A antelope may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the antelope will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Antelope(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(max_age);
        }
    }

    /**
     * This is what the antelope does most of the time - it runs
     * around. Sometimes it will breed or die of old age.
     * @param newAntelopes A list to return newly born antelopes.
     */
    public void act(List<Animal> newAntelopes)
    {
        incrementAge();

        if(isAlive()) {
            if (checkDisease()) {
                diseaseAffects();
                spread();
            }
            if ((getTime() >= wakeUp && getTime() < bedTime)  && isSun()){
                giveBirth(newAntelopes);            
                // Try to move into a free location.
                Location newLocation = getField().freeAdjacentLocation(getLocation());
                if(newLocation != null) {
                    setLocation(newLocation);
                }
            }
            else{
                Location sameLocation = getLocation();
                // Stay in the same location
                setLocation(sameLocation);
            }
        }

        else {
            // Overcrowding.
            setDead();
        }

    }

    /**
     * Increase the age.
     * This could result in the antelope's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > max_age) {
            setDead();
        }
    }

    /**
     * Check whether or not this antelope is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAntelopes A list to return newly born antelopes.
     */
    private void giveBirth(List<Animal> newAntelopes)
    {
        // New antelopes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Antelope young = new Antelope(false, field, loc);
            newAntelopes.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if (mateNear() && canBreed() && (rand.nextDouble() <= BREEDING_PROBABILITY)) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A antelope can breed if it has reached the breeding age.
     * @return true if the antelope can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }

    /**
     * Check if the animal in the adjecent location is the opposite gender and the same animal
     * If they are the opposite gender and the same animal then allow them to breed
     * @return true if they are allowed to breed
     */
    private boolean mateNear() {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        boolean mateFound = false;
        while (!mateFound && it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Antelope){
                if (((Antelope) animal).checkFemale() != this.checkFemale()) {
                    mateFound = true;
                }
            }
        }
        return mateFound;
    }

    /**
     * When the antelope contracts the disease it will lower its life span
     * Every antelope is affected differently by the disease
     * 
     */
    private void diseaseAffects()
    {
        max_age = rand.nextInt(max_age - age + 1) + age;
    }

    /**
     * When an antelope has a disease then its neighbouring antelopes
     * also have a chance of catching the disease
     */
    private void spread() 
    {
        List <Animal> neighbours = new ArrayList <>();
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while (it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if (animal instanceof Antelope && randDisease.nextDouble() <= spreadProbability()) {
                ((Antelope) animal).diseaseAffects();
            }
        }
    }
}
