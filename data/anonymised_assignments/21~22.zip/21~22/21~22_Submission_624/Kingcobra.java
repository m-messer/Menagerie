import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a Kingcobra.
 * Kingcobra age, move, eat sparrows and toads, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Kingcobra extends Animal
{
    // Characteristics shared by all Kingcobra (class variables).
    // number of steps a Kingcobra can go before it has to eat again.
    private static final int SPARROW_FOOD_VALUE = 22;
    private static final int TOAD_FOOD_VALUE = 18;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // Individual characteristics (instance fields).
    // The Kingcobra's age.
    // The Kingcobra's food level, which is increased by eating sparrows.

    /**
     * Create a Kingcobra. A Kingcobra can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Kingcobra will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param location The gender of the Kingcobra
     */
    public Kingcobra(boolean randomAge, Field field, Location location, boolean gender)
    {
        super(field, location,10,33,0.07,4,gender);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(SPARROW_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = SPARROW_FOOD_VALUE + TOAD_FOOD_VALUE;
        }
        this.isFemale = gender;
    }
    
    /**
     * This is what the Kingcobra does most of the time: it hunts for
     * sparrows or toad. In the process, it might breed, die of hunger,
     * or die of old age
     * @param field The field currently occupied.
     * @param newKingcobra A list to return newly born Kingcobra.
     */
    public void act(List<Animal> newKingcobra)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            hasMeet();
            giveBirth(newKingcobra);

            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                overcrowded();
            }
        }
    }
    
    /**
     * Look for sparrow's or toad;s adjacent to the current location.
     * Only the first live animal is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
            while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Sparrow) {
                Sparrow sparrow = (Sparrow) animal;
                if(sparrow.isAlive()) { 
                    sparrow.setDead();
                    deathConsumed();
                    foodLevel = SPARROW_FOOD_VALUE;
                    return where;
                }
            }
            if(animal instanceof Toad) {
                Toad toad = (Toad) animal;
                if(toad.isAlive()) { 
                    toad.setDead();
                    deathConsumed();
                    foodLevel = TOAD_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    /**
     * Check whether or not this Kingcobra is a female and have met a male Kingcobra in adjacent
     * If have met, hasMeet = true, one of the conditions for a Kingcobra to be able to breed (only female can breed)
     */
    private void hasMeet(){
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(this.getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Kingcobra) {
                Kingcobra kingcobra = (Kingcobra) animal;
                if(kingcobra.isFemale && !this.isFemale) { 
                    kingcobra.hasMeet = true;
                }
            }
        
        }
    }
    
    /**
     * Check whether or not this Kingcobra is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newKingcobra A list to return newly born Kingcobra.
     */
    private void giveBirth(List<Animal> newKingcobra)
    {
        // New Kingcobra are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            boolean gender = rand.nextInt(2) == 0 ? false : true;
            Kingcobra young = new Kingcobra(false, field, loc, gender);
            newKingcobra.add(young);
        }
    }
}
