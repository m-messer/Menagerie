import java.util.Random;
import java.util.List;

/**
 * A class representing shared characteristics of animals.
 *
 * @version v1
 */
public abstract class Plant
{
    // Whether the plant is alive or not.
    private boolean alive;
    // The plant's field.
    private Field field;
    // The plant's position in the field.
    private Location location;
    // Whether the plant is poisonous
    private double poison;
    
    private final Random rand = Randomizer.getRandom();
    
    // The age when plant can start pollinating
    protected final int POLLINATION_AGE;
    // The age to which a plant can live.
    protected final int MAX_AGE;
    
    // The likelihood of plant pollinating.
    protected final double POLLINATION_PROBABILITY;
    // The maximum number of new plants being pollinated.
    protected final int MAX_POLLINATION_SIZE;
    // The rate in which the plant can pollinate once
    protected final int GROWTH_RATE;
    //Current age of animal
    protected int age;

    
    /**
     * Create a new plant at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param POLLINATION_AGE The pollination age of animal
     * @param MAX_AGE The max age of animal
     * @param POLLINATION_PROBABILITY The pollination probability of plant
     * @param MAX_POLLINATION_SIZE The max pollination size of plant
     * @param GROWTH_RATE The rest(steps) before a plant can pollinate again
     */
    public Plant(Field field, Location location, int POLLINATION_AGE, int MAX_AGE, double poison, double POLLINATION_PROBABILITY, int MAX_POLLINATION_SIZE, int GROWTH_RATE)
    {
        alive = true;
        this.field = field;
        setLocation(location);
        this.poison = poison;
        this.POLLINATION_AGE = POLLINATION_AGE;
        this.MAX_AGE = MAX_AGE;
        this.POLLINATION_PROBABILITY = POLLINATION_PROBABILITY;
        this.MAX_POLLINATION_SIZE = MAX_POLLINATION_SIZE;
        this.GROWTH_RATE = GROWTH_RATE;
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Plant> newPlants);
    
    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Determines whether the plant will cause animal to be poisoned
     */
    public boolean isPoisoned() {
        return Math.random() > this.poison;
    }
    
    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the plant's location.
     * @return The plants's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Check whether the plant is alive or not.
     * @return true if the plant is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Return the plant's field.
     * @return The plant's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Generate a number representing the number of births,
     * if it can pollinate.
     * @return The number of new plants pollinated (may be zero).
     */
    protected int pollinate()
    {
        int births = 0;
        if(canPollinate() && rand.nextDouble() <= POLLINATION_PROBABILITY) {
            births = rand.nextInt(MAX_POLLINATION_SIZE) + 1;
        }
        return births;
    }
    
    /**
     * Pollinate can pollinate if it has reached the pollination age
     */
    protected boolean canPollinate()
    {
        return age >= POLLINATION_AGE;
    }
}
