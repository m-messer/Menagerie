
import java.util.HashMap;
import java.util.Random;
import java.util.ArrayList;

/**
 * Class to simulate weather.
/**
 * Time Of Day - Predators hunt during day, sleep (not move but feeds) during night
 * Weather Level - Determines the number by which the reproduction number is reduced. e.g. if Normal, reproduction will be divided by 2.
 * The simulation starts of being day 
 * The simulation starts of with a random weather - meaning the weather level will be random too
 * @version 2022.03.02
 */
public class Weather
{
    // field to toggle infection.
    private boolean toggle;
    // field to toggle day and night.
    private boolean day;
    // field for mapping the weather level to the type of weather.
    private HashMap<Integer,String> weather;  
    // field for the level of weather.
    private int weatherLevel;
    // Field for the type of weather.
    private String weatherType;

    /**
     * Constructor for objects of class Weather
     */
    public Weather()
    {
        toggle = false;
        day = false;
        weather = new HashMap<>();
        //add weather to field
        addWeather(1,"Sunny");
        addWeather(2,"Normal");
        addWeather(3,"Rainy");
        addWeather(4,"Drought");

        generateRandomWeather();
    }

    /**
     * Enables the addition of new weather.
     * @param num The level of weather.
     * @param newWeather The type of weather.
     */
    private void addWeather(int num, String newWeather){
        weather.put(num, newWeather);
    }

    /**
     * @return active if infection is true and 
     * inactive if otherwise.
     */
    public String checkInfection(){
        if (toggle){
            return "Active";
        }
        else {
            return "Inactive";
        }
    }

    /**
     * method to toggle infection.
     * @return true if it is day and false if otherwise
     */
    public boolean toggle(){
        toggle = !toggle;
        return toggle;
    }

    /**
     * Method to toggle time of day.
     * @return true if it is day and false if otherwise
     */
    public boolean dayToggle(){
        day = !day;
        return day;
    }

    /**
     * Access the weather level
     * @return weatherLevel The random weather level. eg. 1
     * which maps to sunny
     */
    public Integer getWeatherLevel()
    {
        return  weatherLevel;
    }

    /**
     * @return weatherType
     */
    public String getWeatherType()
    {
        return  weatherType;
    }

    /**
     * Gets the current value stored in toggle.
     *@return true or false 
     */
    public boolean getToggle(){
        return toggle;
    }

    /**
     * Gets the current value stored in day.
     *@return true or false 
     */
    public boolean getDay(){
        return day;
    }

    /**
     * @return Day if day is true and 
     * Night if otherwise.
     */
    public String getTime(){
        if (!day){
            return "Day";
        }
        else {
            return "Night";
        }
    }

    /**
     * Randomly generates weather type.
     */
    public void generateRandomWeather()
    {
        Random rand = new Random();
        weatherLevel = rand.nextInt(weather.size())+1;
        weatherType = weather.get(weatherLevel);
    }
}
