import java.util.List;
/**
 * Interface to be extended by participating classes
 *
 * @version 2022.03.02
 */
public interface Actor
{
    // instance variables - replace the example below with your own

   /**
    * Performs actor general behaviour.
    * @param List of new actors.
    */
    void act(List<Actor> newActors);
   
   /**
    * Indicate whether the actor is active
    * @return true if actor is active and false if otherwise.
    */
    boolean isActive();
   
}
