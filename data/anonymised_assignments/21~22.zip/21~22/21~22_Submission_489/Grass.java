import java.util.List;
import java.util.Random;

/**
 * A simple model of grass.
 * Grass age, reproduce and die.
 * 
 */
public class Grass extends Organism
{

    // The age at which a grass can start to breed.
    private static final int BREEDING_AGE = 0;
    // The age to which a grass can live.
    private static final int MAX_AGE = 2;
    // The likelihood of a grass breeding.
    private static double BREEDING_PROBABILITY = 0.3;
    // The maximum number of births.
    private int MAX_LITTER_SIZE = 7;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // trigger to change breeding probability
    private boolean checker;

    /**
     * Constructor for objects of class Grass
     * @param randomAge If true, the grass will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Grass(boolean randomAge, Field field, Location location)
    {
        super(field, location);

        checker = true;

        if(randomAge) {
            setAge(rand.nextInt(MAX_AGE));
        }
    }
    
    /**
     * Check and get the correct breeding probability 
     * based on whether or not infection is active.
     * @return BREEDING_PROBABILITY The breeding probability of grass
     */
    public double checkBreedingProbability(){
        if (checker){
            return BREEDING_PROBABILITY = 0.2;
        }
        else{
            return BREEDING_PROBABILITY = 0.3;
        }
    }

    /**
     * This is what the grass does most of the time - its idle 
     * Sometimes it will breed or die of old age.
     * In case of infection, it breed less so as in 
     * harsh weather conditions.
     * @param newGrass A list to return reproduced grass.
     */
    @Override
    
    public void act(List newGrass)
    {   
        Field field = getField();
        incrementAge();
        
        if(isActive()) {
            
            if(field.getWeatherType().equals("Drought")){
                MAX_LITTER_SIZE = MAX_LITTER_SIZE % 4;
            }
            else {
                MAX_LITTER_SIZE = 7;
            }

            if(field.getInfection()){
                checker = true;
                checkBreedingProbability();
            }
            else{
                checker = false;
                checkBreedingProbability();
            }

            giveBirth(newGrass);            

        }
    }

    /**
     * Initialise the new grass
     * @param randomAge True if organism will have a random age.
     * @param field The field currently occupied.
     * @param location The location in field.
     */
    @Override
    
    protected Organism createInfant(boolean randomAge, Field field, Location loc){
        return new Grass(randomAge, field, loc);
    }

    /**
     * Access the maximum age of the grass.
     * @return The maximum age of the grass.
     */
    @Override
    
    public int getMaxAge(){
        return MAX_AGE;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    @Override
    
    protected int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * Access the breeding age of the grass.
     * @return The age a grass can reproduce
     */
    @Override
    
    public int getBreedingAge(){
        return BREEDING_AGE;
    }
}
