import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;
/**
 * A class to represent population( to populate the field).
 * 
 * @version 2016.02.29 (2)
 */
public class PopulationGenerator
{
    // The probability that a cheetah will be created in any given grid position.
    private static final double CHEETAH_CREATION_PROBABILITY = 0.011;
    
    // The probability that a lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.012;
    
    // The probability that a wildebeest will be created in any given grid position.
    private static final double WILDEBEEST_CREATION_PROBABILITY = 0.05;  
    
    // The probability that a zebra will be created in any given grid position.
    private static final double ZEBRA_CREATION_PROBABILITY = 0.04;
    
    // The probability that a grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.7;
    
    private List<Actor> actors;
    
    //The current state of the field.
    private Field field;
    
    private SimulatorView view;
    
    /**
     * Constructor for objects of class PopulationGenerator
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public PopulationGenerator(Field field, SimulatorView view)
    {
        this.field = field;
        this.view = view;
        setColor();
    }
    
    /**
     * Set animal colours to display in field.
     */
    private void setColor(){
        // Create a view of the state of each location in the field.
        
        view.setColor(Wildebeest.class, Color.ORANGE);
        view.setColor(Lion.class, Color.BLUE);
        view.setColor(Cheetah.class, Color.BLACK);
        view.setColor(Zebra.class, Color.MAGENTA);
        view.setColor(Grass.class, Color.GREEN);
    }
    
    /**
     * Randomly populate the field with all organisms.
     * @param rand Randomly locate organisms.
     */
    public List<Actor> populate(Random rand)
    {
        List<Actor> actor = new ArrayList<>();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {
                if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Lion lion = new Lion(true, field, location);
                    actor.add(lion);
                }
                else if(rand.nextDouble() <= CHEETAH_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Cheetah cheetah = new Cheetah(true, field, location);
                    actor.add(cheetah);
                }
                else if(rand.nextDouble() <= WILDEBEEST_CREATION_PROBABILITY) {
                    Location location = new Location(row, col);
                    Wildebeest wildebeest = new Wildebeest(true, field, location);
                    actor.add(wildebeest);
                }
                else if(rand.nextDouble() <= ZEBRA_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Zebra zebra = new Zebra(true, field, location);
                    actor.add(zebra);
                }
                else if(rand.nextDouble() <= GRASS_CREATION_PROBABILITY){
                    Location location = new Location(row, col);
                    Grass grass = new Grass(true, field, location);
                    actor.add(grass);
                }
                // else leave the location empty.
            }
        }
        return actor;
    }
}
