import java.awt.*;
import java.util.List;

/**
 * A class representing shared characteristics of plants
 *
 * @version 2022.03.01
 */
public abstract class Plant extends Creature {

	/**
	 * Create a new plant at location in field 
	 * @param field The field currently occupied.
	 * @param location The location within the field 
	 */
    public Plant(Field field, Location location)
    {
        super(field, location);
    }
    
    /**
     * Make this plant breed
     * @param newPlants A list to receive new plants
     * @param Weather A sting that specifies the weather in the simulator
     */
    abstract public void reproduce(List<Plant> newPlants, String Weather);
    
    /**
     * Increase the hydration level of the plant by a certain amount
     * @param n An int value that holds the amount added to hydration level
     */
    abstract protected void increment_hydration(int n);
    
    /**
     * Decrease the hydration of the plant by a certain amount
     * @param n An int value the hold the amount deducted from hydration
     */
    abstract protected void decrement_hydration(int n);

    /**
     * Return a color object that hold the plant color in the simulator
     * @return A color object that holds the plant color
     */
    abstract public Color getColor();
    
    /**
     * Return the nutrition vale of the plant
     * @return An int value that represent the plant value as a food
     */
    abstract public int getFoodValue();


}