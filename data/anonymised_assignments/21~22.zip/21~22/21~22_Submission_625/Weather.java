import java.util.Random;

/**
 * Represent a weather in a simulator 
 *
 * @version 2022.03.01
 */
public class Weather {

	// a name of the season 
    private String season;
    // the weather conditions probability 
    private String currentWeather ;
    private double rainProbability;
    private double fogProbability;
    private double windProbability;
    private double snowProbability;
    
    // to generate random numbers 
    private static final Random rand = Randomizer.getRandom();

    /**
     * Represent the season name and its weather condition probabilities 
     * 
     * @param seasonName the name of the season 
     * @param rain the rain probability during the season
     * @param snow the snow probability during the season 
     * @param fog the fog probability during the season 
     * @param wind the wind probability during the season
     */
    public Weather(String seasonName, double rain, double snow, double fog, double wind)
    {
        season = seasonName;
        rainProbability = rain;
        snowProbability = snow;
        fogProbability = fog;
        windProbability = wind;

    }

    /**
     * Return a string of the form rainy day, as an example
     * @return A string representation of the current weather in the day 
     */
    public String getWeather()
    {
        return currentWeather;
    }
    
    /**
     * Changes the string of currentWeather 
     * @param state A string that specifies the weather 
     */
    public void updateWeather(String state)
    {
        currentWeather = state;
    }
    
    /**
     * Return a string of the season name in the form Summer, as an example
     * @return	a String that specifies the season name 
     */
    public String getSeasonName()
    {
        return season;
    }

    /**
     * use a random number to determine the weather in the simulator and updates the currentWeather
     */
    public void chooseWeather()
    {
        double chance = rand.nextDouble();

        if (rainProbability > chance)
        {
            updateWeather("Rainy day");
        }
        else if(snowProbability > chance)
        {
            updateWeather("Foggy day");
        }
        else if(fogProbability > chance)
        {
            updateWeather("Windy day");
        }
        else if(windProbability > chance)
        {
            updateWeather("Snowy day");
        }
        else {
            updateWeather("Sunny day");
        }

    }

}
