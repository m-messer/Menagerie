import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple model of a deer.
 * Deers age, move, eat, breed and die.
 *
 * @version 2022.03.01
 *
 */
public class Deer extends Animal
{
    // Characteristics shared by all deer (class variables).

    // The age at which a deer can start to breed.
    private static final int BREEDING_AGE = 7;
    // The age to which a deer can live.
    private static final int MAX_AGE = 500;
    // The likelihood of a deer breeding.
    private static final double BREEDING_PROBABILITY = 0.20;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The nutrition value that the predator will gain from the deer 
    private static final int FOOD_VALUE = 50;
    // The maximum urge to breed
    private static final int BREEDING_URGE_LIMIT = 5;
    // The minimum hunger 
    private static final int MIN_HUNGER = 35;
    // The length of pregnancy for deers
    private static final int PREGNANCY_LENGTH = 7;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    // The colors of each sex of deers
    private Color maleColor = new Color(145,111,33);
    private Color femaleColor = new Color(145,121,65);

    // Individual characteristics (instance fields) 
    // The deer's age.
    private int age;
    // The deer's food level, which increase by eating grass
    private int foodLevel = 45;
    // The sex of the deer
    private boolean male;
    // The urge of breeding counter 
    private int breedingUrge = 0;
    // Determine if the deer in pregnant or not
    private boolean isPregnant;
    // the duration counter of current pregnancy 
    private int pregnancyCounter = 0;
    // number of fetus
    private int withChild;


    /**
     * Create a new deer. A deer may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the deer will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Deer(boolean randomAge, Field field, Location location)
    {
    	 super(field, location);
         age = 0;
         male = (rand.nextInt(2) == 1);
         if(randomAge) {
             age = rand.nextInt(MAX_AGE);
         }
    }

    /**
     * This is what the deer does most of the time - it runs
     * around. Sometimes it will breed or die of old age.
     * @param newDeer A list to return newly born deer.
     * @param weather A sting that specifies the weather in the simulator
     */
    public void act(List<Animal> newDeer, String weather)
    {
    	incrementAge();
        incrementHunger();
        incrementPregnancyCounter();
        applyWeatherEffect(weather);

        if(isAlive()) {
            giveBirth(newDeer);
            // Try to move to a location that has a point of interest to the creature
            Location interestingLocation = pointOfInterest();
            if(interestingLocation != null)
                setLocation(interestingLocation);
            else {
                // Try to move into a free location.
                Location newLocation = getField().freeAdjacentLocation(getLocation());
                if (newLocation != null) {
                    setLocation(newLocation);
                } else {
                    // Overcrowding.
                    setDead();
                }
            }
        }

    }
    
    /**
     * Change the action of the deer depending on the weather condition
     * @param weather A string that indicates the weather condition in the simulator 
     */
    protected void applyWeatherEffect(String weather )
    {
        if(weather.equals("Rainy day")) {
            incrementBreedingUrge();
            findMate();
            findFood();
        }
        else if(weather.equals("Foggy day")) {
            incrementBreedingUrge();
        	findMate();
        }
        else if(weather.equals("Snowy day")) {
            findFood();
        }
        else if(weather.equals("Windy day") || weather.equals("Sunny day")) {
            incrementBreedingUrge();
        	findFood();
            findMate();
        }

    }
      

    /**
     * Look for grass adjacent to the current location.
     * and then eat it
     * @return A location of the food source or null if not found
     */
    private Location findFood()
    {
    	 Field field = getField();
         if(foodLevel < MIN_HUNGER)
         {
             if (field != null) {
            	 //store a list of adjacent locations that has food that are 4 blocks away or less 
                 List<Location> adjacent = field.furtherAdjacentLocations(getLocation(), 4);
                 Iterator<Location> it = adjacent.iterator();
                 while (it.hasNext()) {
                     Location where = it.next();
                     Creature creature = (Creature) field.getObjectAt(where);
                     if (creature instanceof Grass) {
                         if (creature.isAlive()) {
                             creature.setDead();
                             increaseFoodLevel(creature.getFoodValue());
                             return where;
                         }
                     }
                 }
             }
         }
         return null;
    }

    /**
     * This method helps the deer to find its mate location to start breeding
     */
    private void findMate()
    {
    	Field field = getField();
        if (field!= null) {
       	 	//store a list of adjacent locations that has mates
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
            while (it.hasNext()) {
                Location where = it.next();
                Object mate = field.getObjectAt(where);
                if (mate instanceof Deer) {
                    Deer deer = (Deer) mate;
                    if (this.isMale() && !deer.isMale() && BREEDING_URGE_LIMIT < this.breedingUrge &&
                            BREEDING_URGE_LIMIT < deer.getBreedingUrge())
                    {
                        deer.impregnate();
                        deer.breed();
                        this.resetBreedingUrge();
                        deer.resetBreedingUrge();
                    }
                }
            }
        }
    }
    

    /**
     * Check whether or not this deer is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newDeer A list to return newly born deer.
     */
    private void giveBirth(List<Animal> newDeer)
    {
    	if(isPregnant && pregnancyCounter >= PREGNANCY_LENGTH)
        {
            // New deer are born into adjacent locations.
            // Get a list of adjacent free locations.
            Field field = getField();
            List<Location> free = field.getFurtherFreeAdjacentLocations(getLocation(), 2);
            int births = withChild;
            for (int b = 0; b < births && free.size() > 0; b++) {
                Location loc = free.remove(0);
                Deer young = new Deer(false, field, loc);
                newDeer.add(young);
            }
            withChild = 0;
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private void breed()
    {

    	if(!isMale() && isPregnant) {
            int births;
            if (canBreed()) {
                births = rand.nextInt(MAX_LITTER_SIZE) + 1;
                withChild = births;
            }
        }

    }
    
    /**
     * This method find the closet food source, mate or predator location which 
     * effect the next taken action by deer. 
     * @return A location that its adjacent location are either 
     * a food source, mate or predator 
     */
    private Location pointOfInterest()
    {
    	Field field = getField();
        ArrayList<Location> foodLocations = new ArrayList<>();
        ArrayList<Location> mateLocations = new ArrayList<>();
        ArrayList<Location> predatorLocations = new ArrayList<>();

        if(field != null)
        {
            List<Location> adjacent = field.furtherAdjacentLocations(getLocation(), 4);
            Iterator<Location> it = adjacent.iterator();
            // Iterates the list of location depending on the depth
            while (it.hasNext())
            {
                Location where = it.next();
                List<Location> adjacentToTheAdjacent = field.getFreeAdjacentLocations(where);
                Iterator<Location> secondIt = adjacentToTheAdjacent.iterator();
                // iterates the adjacent locations of the locations that are in the main locations list
                while (secondIt.hasNext())
                {
                    Location whereAdjacent = secondIt.next();
                    Creature creature = (Creature) field.getObjectAt(whereAdjacent);
                    //adds a location to the predators list which has predators nearby, that prey on this animal
                    if (creature instanceof Wolf) {
                        predatorLocations.add(where);
                        break;
                    }
                    //adds a location to the food list which has food sources nearby, that this animal feed on
                    else if (creature instanceof Grass) {
                        foodLocations.add(where);
                        break;
                    }
                    // adds a location to the mate list which has potential mates nearby, that this animal needs to breed
                    else if (creature instanceof Deer && (((Deer) creature).isMale() != this.isMale())) {
                        mateLocations.add(where);
                        break;
                    }

                }
            }
            double chance = rand.nextDouble();

            if(foodLevel < MIN_HUNGER){
                if(chance < 0.75) {
                    if (foodLocations.size() > 0)
                        return foodLocations.get(rand.nextInt(foodLocations.size()));
                }
                else if (chance < 0.90)
                {
                    if (mateLocations.size() > 0)
                        return mateLocations.get(rand.nextInt(mateLocations.size()));
                }
                else
                    if(predatorLocations.size() > 0)
                        return predatorLocations.get(rand.nextInt(predatorLocations.size()));
            }
            else if (breedingUrge > BREEDING_URGE_LIMIT){
                if(chance < 0.75) {
                    if (mateLocations.size() > 0)
                        return mateLocations.get(rand.nextInt(mateLocations.size()));
                }
                else if (chance < 0.90)
                {
                    if (foodLocations.size() > 0)
                        return foodLocations.get(rand.nextInt(foodLocations.size()));
                }
                else
                    if(predatorLocations.size() > 0)
                        return predatorLocations.get(rand.nextInt(predatorLocations.size()));
            }
            else {
                if(chance < 0.35) {
                    if (mateLocations.size() > 0)
                        return mateLocations.get(rand.nextInt(mateLocations.size()));
                }
                else if (chance < 0.70)
                {
                    if (foodLocations.size() > 0)
                        return foodLocations.get(rand.nextInt(foodLocations.size()));
                }
                else {
                	if(predatorLocations.size() > 0)
                        return predatorLocations.get(rand.nextInt(predatorLocations.size()));
                }
     
            }
        }

        return null;
    }

    /**
     * return the color of the deer based on its gender
     * @return A color object that indicates the color of deer
     */
    public Color getColor()
    {
        if(male) return maleColor;
        else return femaleColor;
    }
    
    /**
     * Increase the food level of deer by a certain amount
     * @param num The amount that will be added to the food level
     */
    private void increaseFoodLevel(int num)
    {
        foodLevel += num;
    }

    /**
     * Increase the age.
     * This could result in the deer's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * increase the hunger 
     * This could result in the deer's death
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel < 0){
            setDead();
        }
    }
	
	/**
	 * increase the pregnancy period counter for female deer
	 */
    private void incrementPregnancyCounter(){
        pregnancyCounter++;
    }

    /**
     * increase the urge to breed for a certain deer 
     */
    private void incrementBreedingUrge()
    {
        breedingUrge++;
    }
    
    /**
     * Resets the breeding urge to zero
     */
    private void resetBreedingUrge()
    {
        breedingUrge = 0;
    }
    
    /**
     * Return the breeding urge of the deer
     * @return An int value that holds the breeding urge
     */
    private int getBreedingUrge()
    {
        return breedingUrge;
    }
    
    /**
     * Return the Food value of the deer 
     * @return A int value that hold the food value
     */
    public int getFoodValue(){ return FOOD_VALUE;}

    /**
     * Determine whether the deer in pregnant or not
     */
    private void impregnate()
    {
        isPregnant = rand.nextDouble() <= BREEDING_PROBABILITY;
    }

    /**
     * determine the sex of the deer.
     * if it was a male it will return true, false otherwise.
     * @return A boolean variable that determine the sex of the deer
     */
    private boolean isMale(){
        return male;
    }

    /**
     * A deer can breed if it has reached the breeding age.
     * @return true if the deer can breed, false otherwise.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
