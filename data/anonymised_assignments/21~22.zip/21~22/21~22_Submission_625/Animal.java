import java.awt.*;
import java.util.List;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2022.03.01
 */
public abstract class Animal extends Creature
{

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        super(field, location);
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     * @param weather A sting that specifies the weather in the simulator
     */
    abstract public void act(List<Animal> newAnimals, String weather);
    
    /**
     * Return a color object that hold the animal color in the simulator 
     * @return A color object that holds animal's color depending on its gender 
     */
    abstract public Color getColor();

}
