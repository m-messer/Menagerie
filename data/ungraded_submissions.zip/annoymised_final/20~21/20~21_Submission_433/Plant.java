import java.util.Random;
import java.util.List;
/**
 * A simple model of all plants.
 * Plants can age, reproduce, and die.
 *
 * @date 02/03/2021
 */
public class Plant
{
    // Characteristics shared by all plants (class variables).

    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The maximum range within which the plant can reproduce.
    private static final int MAX_EFFECTIVE_RANGE = 1;
    // The maximum seedlings a plant can give birth to.
    private static final int MAX_SEEDLINGS_SIZE = 1;
    // The likelihood of a plant reproducing.
    private static final double REPRODUCING_PROBABILITY = 0.04;
    // The default rate at which a plant grows.
    private static final int DEFAULT_GROWTH_RATE = 1;
    // The age at which a plant can be eaten.
    private final static int WHEN_EDIBLE = 2;

    // Whether the plant is alive or not.
    private boolean alive;
    // The plant's field.
    private Field field;
    // The plant's position in the field.
    private Location location;
    // The plant's age.
    private int age;
    // The rate at which a plant grows.
    private int growthRate;

    /**
     * Create a new plant at location in field.
     * 
     * @param random If true, the plant will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Plant(boolean random, Field field, Location location)
    {   
        this.alive = true;
        this.field = field;
        setLocation(location);
        this.growthRate = DEFAULT_GROWTH_RATE;
        if(random) {
            age = rand.nextInt(100);
        }
        else {
            age = 0;
        }
    }

    /**
     * This is what the plant does most of the time.
     * In the process it might age, or reproduce.
     */
    public void act(List<Plant> newPlants){
        if (isAlive()){
            incrementAge();
            reproduce(newPlants);
        }
    }

    /**
     * Check whether or not this plant is to reproduce at this step.
     * New plants will be made into free adjacent locations within the maximum effective range.
     * @param newPlants A list to return newly reproduced plants.
     */
    private void reproduce(List<Plant> newPlants)
    {
        // New plants are created into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation(), MAX_EFFECTIVE_RANGE);
        int reproductions = canReproduce();
        for(int b = 0; b < reproductions && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plant young = new Plant(false, field, loc);
            newPlants.add(young);
        }
    }

    /**
     * Generate a number representing the number of reproductions,
     * if it can breed.
     * @return The number of reproductions (may be zero).
     */
    private int canReproduce()
    {
        int reproductions = 0;
        if(rand.nextDouble() <= REPRODUCING_PROBABILITY) {
            reproductions = rand.nextInt(MAX_SEEDLINGS_SIZE) + 1;
        }
        return reproductions;
    }

    /**
     * Indicate that the plant is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Check whether the plant is alive or not.
     * @return true if the plant is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Checks whether the plant is edible or not.
     * @return true if the plant is edible, false otherwise.
     */
    protected boolean isEdible()
    {
        return age >= WHEN_EDIBLE;
    }

    /**
     * Place the plant at the new location in the given field.
     * @param newLocation The plant's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }

    /**
     * Return the plant's location.
     * @return The plant's location.
     */
    protected Location getLocation()
    {
        return location;
    }

    /**
     * Return the plant's field.
     * @return The plant's field.
     */
    protected Field getField()
    {
        return field;
    }

    /**
     * Increase the age according to the growth rate.
     */
    private void incrementAge()
    {
        age = age + growthRate;
    }

    /**
     * Sets growth rate on rainy weather.
     */
    public void rain()
    {
        growthRate = 2;
    }

    /**
     * Sets growth rate on clear weather.
     */
    public void clearDay(){
        growthRate = DEFAULT_GROWTH_RATE;
    }
}
