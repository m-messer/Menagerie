import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A simple model of a KangarooRat.
 * KangarooRats age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class KangarooRat extends Species
{
    // Characteristics shared by all KangarooRats (class variables).

    // The age at which a KangarooRat can start to breed.
    private static final int BREEDING_AGE = 0;
    // The age to which a KangarooRat can live.
    private static final int MAX_AGE = 75;
    // The likelihood of a KangarooRat breeding.
    private static final double BREEDING_PROBABILITY = 0.68;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 45;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    private static final int Cactus_FOOD_VALUE = 30;
    // Individual characteristics (instance fields).

    // The KangarooRat's age.
    private int age;

    private int foodLevel;

    /**
     * Create a new KangarooRat. A KangarooRat may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the KangarooRat will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param sex The sex of the species.
     */
    public KangarooRat(boolean randomAge, Field field, Location location, String sex)
    {
        super(field, location, sex);
        age = 0;
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(Cactus_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = Cactus_FOOD_VALUE;
        }
    }

    /**
     * This is what the KangarooRat does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newKangarooRats A list to return newly born KangarooRats.
     * @param isNight A boolean value when true it is night time and KangarooRats are dormant.
     * @param weather The current weather.
     */
    public void act(List<Species> newKangarooRats, Boolean isNight, String weather)
    {
        if(!isNight){   
            incrementAge();
            incrementHunger();
            if(isAlive()) {
                giveBirth(newKangarooRats);     
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }

            }
        }

    }

    /**
     * Increase the age.
     * This could result in the KangarooRat's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }

    /**
     * Make this KangarooRat more hungry. This could result in the KangarooRat's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }

    /**
     * Look for Cactus adjacent to the current location.
     * Only the first live Cactus is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object Species = field.getObjectAt(where);
            //Uses eating probability to allow the other species to grow
            Random rand = new Random();
            int eating_prob = rand.nextInt(100);
            if(Species instanceof Cactus && eating_prob < 35) {
                Cactus Cactus = (Cactus) Species;
                if(Cactus.isAlive()) { 
                    Cactus.setDead();
                    foodLevel = Cactus_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }

    /**
     * Check whether or not this KangarooRat is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newKangarooRats A list to return newly born KangarooRats.
     */
    private void giveBirth(List<Species> newKangarooRats)
    {
        // New KangarooRats are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        String sex = getSex();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            KangarooRat young = new KangarooRat(false, field, loc, sex);
            newKangarooRats.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY && age >= BREEDING_AGE) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A KangarooRat can breed if it has reached the breeding age and if it is nearby the location of a lizard of the opposite sex.
     * @return true if the KangarooRat can breed, false otherwise.
     */
    private boolean canBreed()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object Species = field.getObjectAt(where);
            if(Species instanceof KangarooRat) {
                KangarooRat KangarooRat = (KangarooRat) Species;
                if(KangarooRat.getSex() != getSex()) { 
                    return true;
                }else{
                    return false;
                }
            }
        }
        return false;
    }
}
