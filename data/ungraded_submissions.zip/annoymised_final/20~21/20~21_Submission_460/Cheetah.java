import java.util.List;
import java.util.Iterator;

/**
 * This class for the cheetahs in the simulation.
 * 
 *
 * @version (03/03/2021)
 */
public class Cheetah extends Predator
{
    

    /**
     * Constructor for objects of class Cheetah
     */
    public Cheetah(boolean randomAge, Field field, Location location, Time clock)
    {
        super(field, location, clock);
        BREEDING_AGE = 15;
        MAX_AGE = 160;
        BREEDING_PROBABILITY = 0.08;
        MAX_LITTER_SIZE = 2;
        name="Cheetah";

        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            //foodLevel = rand.nextInt(GAZELLE_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = GAZELLE_FOOD_VALUE;
        }
    }

    /**
     * This method controls the behavior of the cheetahs.
     * They can get diseases, die, age, and get hungry.
     */public void act(List<Animal> newcheetah)
    {
        checkForDisease();
        checkInfected();
        if(clock.getHour() < 19 && clock.getHour() > 7) {
            incrementAge();
            incrementHunger();
            if(isAlive()) {
                giveBirth(newcheetah);            
                // Move towards a source of food if found.
                Location newLocation = findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
        }
        //checkForDisease();
    }

    /**
     * Check whether or not this cheetah is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newcheetah A list to return newly born cheetahes.
     */
    private void giveBirth(List<Animal> newcheetah)
    {
        // New cheetahes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Cheetah young = new Cheetah(false, field, loc, clock);
            newcheetah.add(young);
        }
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * @return name of the cheetah.
     */
    protected String getName()
    {
        return name;
    }

    /**
     * Checks if the cheeetahs that are in adjecent locations are of opposite genders.
     * @return true if they are
     * @return false if they are not
     */
    protected boolean difSexBreed()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Cheetah) {
                Cheetah cheetah = (Cheetah) animal;
                if(this.isMale() == cheetah.isMale()) { 
                    return true;
                }
            }
        }
        return false;
    }
}
