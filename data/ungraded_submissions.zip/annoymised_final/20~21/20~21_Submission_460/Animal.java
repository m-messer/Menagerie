import java.util.List;
import java.util.Random;
import java.util.Iterator;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal extends Actor
{

    protected int BREEDING_AGE;
    // The lion's food level, which is increased by eating gazelles.
    protected int foodLevel;

    protected String name;
    protected boolean isAnimalMale;
    protected static final double INFECTION_PROBABILITY = 0.0002;
    protected static final double TRANSMISSION_PROBABILITY = 0.09;
    protected static final double FATALITY_PROBABILITY = 0.05;
    protected static final double RECOVERY_PROBABILITY = 0.3;
    protected boolean isInfected;

    //protected Time clock;

    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location, Time clock)
    {
        super(field, location, clock);
        this.clock = clock;
        // alive = true;
        // this.field = field;
        // setLocation(location);
        foodLevel=5;

        if(rand.nextInt(2) == 0) {
            isAnimalMale = true;
        }
        else {
            isAnimalMale = false;
        }

        if(rand.nextDouble() <= INFECTION_PROBABILITY) {
            isInfected = true;
        }
        else {
            isInfected = false;
        }

    }
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);

    /**
     * Make this lion more hungry. This could result in the lion's death.
     */
    protected void incrementHunger()
    {
        this.foodLevel--;
        if(foodLevel == 0) {
            setDead();
        }
    }

    protected int getFoodLevel()
    {
        return foodLevel;
    }

    abstract protected String getName();

    protected boolean isMale()
    {
        return isAnimalMale;
    }

    abstract protected boolean difSexBreed();

    /**
     * A lion can breed if it has reached the breeding age.
     */
    protected boolean canBreed()
    {
        return (age >= BREEDING_AGE) && difSexBreed();
    }

    abstract protected Location findFood();

    /**
     * @return isInfected.
     */
    protected boolean getInfected()
    {
        return isInfected;
    }

    /**
     * Changes the infection to its opposite
     */
    protected void changeInfection()
    {
        isInfected = !isInfected;
    }

    /**
     * Look for gazelles adjacent to the current location.
     * Only the first live gazelle is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    protected Location checkForDisease()
    {
        Field field = getField();
        //System.out.println(field1 == null);
        //Object current = field.getObjectAt(getLocation());

        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        //System.out.println(this.isInfected);
        if(this.isInfected == true) {
            while(it.hasNext()) {
                Location where = it.next();
                Object animal = field.getObjectAt(where);
                if(animal instanceof Animal) {
                    Animal newAnimal = (Animal) animal;
                    if(rand.nextDouble() <= TRANSMISSION_PROBABILITY) {
                        newAnimal.changeInfection();
                        //System.out.println("another one infected");
                    } 
                }
            }
        }
        return null;
    }

    /**
     * Determines if the victim of the virus will recover or die from the disease.
     */
    protected void checkInfected()
    {
        if(isInfected) {

            if(rand.nextDouble() <= RECOVERY_PROBABILITY) {
                changeInfection();
            }
            else if(rand.nextDouble() <= FATALITY_PROBABILITY) {
                setDead();
            }

        } 
    }
}
