import java.util.Random;

/**
 * Abstract class Actor - this class for everything that acts in the simulation.
 * It contains information common in all actors.
 *
 * @version (03/03/2021)
 */
public abstract class Actor
{
    // Whether the animal is alive or not.
    protected boolean alive;
    // The animal's field.
    protected Field field;
    // The animal's position in the field.
    protected Location location;
    
    protected int age;
    protected int MAX_AGE;
    
    // A shared random number generator to control breeding.
    protected static final Random rand = Randomizer.getRandom();
    
    protected Time clock;
    
    /**
     * Constructor for class Actor
     * @param field, loctaion, and time
     */
    public Actor(Field field, Location location, Time clock)
    {
        this.clock = clock;
        alive = true;
        this.field = field;
        setLocation(location);
        //System.out.println(this.field == null);
    }
    
    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    public boolean isAlive()
    {
        return alive;
    }
    
    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        //System.out.println(this.field == null);
        return field;
    }
    
    /**
     * Increase the age. This could result in the lion's death.
     */
    protected void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * @return age of actor. 
     */
    protected int getAge()
    {
        return age;
    }
}
