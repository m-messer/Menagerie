import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a hawk.
 * Hawks age, move, eat goats, and die.
 *
 * @version 2021.3.2
 */
public class Hawk extends Animal
{
    // Characteristics shared by all hawks (class variables).
    
    // The age at which a hawk can start to breed.
    private static final int BREEDING_AGE = 10;
    // The age to which a hawk can live.
    private static final int MAX_AGE = 90;
    // The likelihood of a hawk breeding.
    private static final double BREEDING_PROBABILITY = 0.96;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 300;
    // The food value of a single goat. In effect, this is the
    // number of steps a hawk can go before it has to eat again.
    private static final int GOAT_FOOD_VALUE = 80;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The hawk's age.
    private int age;
    // The hawk's food level, which is increased by eating goats.
    private int foodLevel;

    /**
     * Create a hawk. A hawk can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the hawk will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hawk(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(GOAT_FOOD_VALUE);
        }
        else {
            age = 0;
            foodLevel = GOAT_FOOD_VALUE;
        }
    }
    
    /**
     * This is what the hawk does during daytime when sunny: it hunts for
     * goats. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newHawks A list to return newly born hawks.
     */
    public void act(List<Animal> newHawks)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newHawks);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
        }
    }
    
    /**
     * This is what the hawk does during night when sunny - it does nothing
     * Sometimes it will die of old age
     */
    public void sleep(List<Animal> newHawks)
    {
        incrementAge();
    }
    
    /**
     * This is what the hawk does when rainy -
     * Sometimes it will breed, die of old age or die of hunger.
     */
    public void rest(List<Animal> newHawks)
    {
        incrementAge();
        incrementHunger();
        if(isAlive()) {
            giveBirth(newHawks);            
        }
    }

    /**
     * Increase the age. This could result in the hawk's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this hawk more hungry. This could result in the hawk's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for goats adjacent to the current location.
     * Only the first live goat is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Goat) {
                Goat goat = (Goat) animal;
                if(goat.isAlive()) { 
                    goat.setDead();
                    foodLevel = GOAT_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this hawk is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newHawks A list to return newly born hawks.
     */
    private void giveBirth(List<Animal> newHawks)
    {
        // New hawks are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Hawk young = new Hawk(false, field, loc);
            newHawks.add(young);
        }
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A hawk can breed if it has reached the breeding age
     * and whether this hawk adjacent to a opposite sex hawk.
     */
    private boolean canBreed()
    {
        Field field = getField();
        List<Location> occupied = field.adjacentLocations(getLocation());
        for(int i = 0 ; i<occupied.size() ; i++){
            Object aroundAni = field.getObjectAt(occupied.get(i));
            if(aroundAni instanceof Hawk) {
                Hawk hawk = (Hawk) aroundAni;
                if(hawk.getGender() == this.getGender()){
                    return false;        
                }
                else{
                    if(age >= BREEDING_AGE){
                        return true;
                    }                  
                }
            }
        }
        return false;
    }
}
