import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a wolf.
 * wolfes age, move, eat hares, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Wolf extends Animal
{
    // Characteristics shared by all wolfes (class variables).
    
    // The age at which a wolf can start to breed.
    private static final int BREEDING_AGE = 3;
    // The age to which a wolf can live.
    private static final int MAX_AGE = 150;
    // The likelihood of a wolf breeding.
    private static final double BREEDING_PROBABILITY = 0.07;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single hare. In effect, this is the
    // number of steps a wolf can go before it has to eat again.
    private static final int RABBIT_FOOD_VALUE = 15;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
    // Individual characteristics (instance fields).
    // The wolf's age.
    private int age;
    // The wolf's food level, which is increased by eating hares.
    private int foodLevel;

    
    /**
     * Create a wolf. A wolf can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the wolf will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Wolf(boolean randomAge, Field field, Location location, boolean isMale, boolean isInfected)
    {
        super(field, location, isMale, isInfected);
        
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
            foodLevel = rand.nextInt(RABBIT_FOOD_VALUE);
            isMale = makeGender();
        }
        else {
            age = 0;
            foodLevel = RABBIT_FOOD_VALUE;
            isMale = makeGender();
        }
    }
    
    /**
     * This is what the wolf does most of the time: it hunts for
     * hares. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newWolves A list to return newly born wolfes.
     */
    public void act(List<Animal> newWolves)
    {
        Random rando = Randomizer.getRandom();
        incrementAge();
        incrementHunger();
        
       
        if(isAlive()) {
           
            //If the weather is sunny, wolf is eager to find food
            if(Simulator.getWeather().equals("Sunny")) { giveBirth(newWolves);}
        
            giveBirth(newWolves);            
            // Move towards a source of food if found.
            Location newLocation = findFood();
            
            if((Simulator.getSteps() % 24 > 12) && rando.nextDouble() > 0.5)
            {
                giveBirth(newWolves); //50% chance to attempt to give birth during night time
            }
            
            if(newLocation == null) { 
                // No food found - try to move to a free location.
                newLocation = getField().freeAdjacentLocation(getLocation());
            }
            // See if it was possible to move.
            if(newLocation != null) {
                setLocation(newLocation);
            }
            else {
                // Overcrowding.
                setDead();
            }
             if(isAlive()){infectAnimals();}
        }
    }

    
    /**
     * Increase the age. This could result in the wolf's death.
     */
    private void incrementAge()
    {
        age++;
        if(age > MAX_AGE) {
            setDead();
        }
    }
    
    /**
     * Make this wolf more hungry. This could result in the wolf's death.
     */
    private void incrementHunger()
    {
        foodLevel--;
        if(foodLevel <= 0) {
            setDead();
        }
    }
    
    /**
     * Look for hares adjacent to the current location.
     * Only the first live hare is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    private Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Hare) {
                Hare hare = (Hare) animal;
                if(hare.isAlive()) { 
                    hare.setDead();
                    foodLevel = RABBIT_FOOD_VALUE;
                    return where;
                }
            }
        }
        return null;
    }
    
    /**
     * Check whether or not this wolf is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newWolves A list to return newly born wolfes.
     */
    private void giveBirth(List<Animal> newWolves)
    {
        // New wolfes are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        
         //Checks if the animal has collided with one of the opposite sex (to breed)
            
            List<Location> locs = field.adjacentLocations(getLocation());
    
            for(int count = 0; count < locs.size(); count++)
            {
                Object o = field.getObjectAt(locs.get(count));
                if(o instanceof Wolf) 
                {
                    Wolf wolf = (Wolf) o;
                    if ((wolf.getGender()) != getGender()) 
                    {
                        count = locs.size();
                        for(int b = 0; b < births && free.size() > 0; b++)
                        {
                            Location loc = free.remove(0);
                            Wolf young = new Wolf(false, field, loc, makeGender(), false);
                            newWolves.add(young);
                    }
                }
            }
        }
        
    }
        
    /**
     * Generate a number representing the number of births,
     * if it can breed.
     * @return The number of births (may be zero).
     */
    private int breed()
    {
        int births = 0;
        if(canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    /**
     * A wolf can breed if it has reached the breeding age.
     */
    private boolean canBreed()
    {
        return age >= BREEDING_AGE;
    }
}
