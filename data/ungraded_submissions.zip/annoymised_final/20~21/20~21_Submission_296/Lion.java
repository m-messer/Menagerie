import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * This class represents characteristic of a Lion.
 * A simple model of Lion
 * Some lions sleep at night time
 * Lions eat preys only
 * Lions age, move, breed, and die.
 *
 * 
 * @version 2021.03.01
 */
public class Lion extends Predator
{
    // instance variables - replace the example below with your own
    // Characteristics shared by all Lions (class variables).

    // The age at which a Lion can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a Lion can live.
    private static final int MAX_AGE = 1000; 
    // The likelihood of a Lion breeding.
    private static final double BREEDING_PROBABILITY = 0.0475;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 1;
    // The food value of a single animal. In effect, this is the
    // number of steps a Lion can go before it has to eat again.
    private static final int MAX_FOOD_LEVEL = 90;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Lion
     */
    public Lion(boolean randomAge, Field field, Location location,boolean gender,boolean haveDisease)
    {
        super(randomAge, field, location,gender,haveDisease);
        
    }
    
    /**
     * This is what the Lion does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * Some lions sleep at night
     * @param field The field currently occupied.
     * @param newLions A list to return newly born Lion.
     */
    public void act(List<LivingThing> newLions)
    {
       super.incrementAge();
       //check if they got disease
       super.checkDisease();
       
       //hunt in day time
       if (!nightTime()){
            super.incrementHunger();
            if(isAlive()) {
                super.mating(newLions); 
                // Move towards a source of food if found.
                Location newLocation = super.findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
       }
       //otherwise some Lion sleeps at night time
    }
  
    /**
     * @return MAX_AGE, max age of Lion
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * @return BREEDING_PROBABILITY , breeding probability of Lion
     * In other words, chance of it giving new born Lion
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * @return MAX_LITTER_SIZE, max litter size of Lion when
     * giving birth while mating
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return BREEDING_AGE, age Lion has to reached before
     * it can breed
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * @return foodLevel, food level of Lion. In effects,
     * the step Lion has left before it has to eat again
     */
    protected int getFoodLevel()
    {
        return foodLevel;
    }
    
    /**
     * @return MAX_FOOD_LEVEL, max food level of Lion
     */
    protected int getMaxFoodLevel()
    {
        return MAX_FOOD_LEVEL;
    }
    
    /**
     * @return haveDisease The status of this Lion having
     * disease or not
     */
    protected boolean getAnimalDisease()
    {
        return haveDisease;
    }
    
    /**
     * Create new instance of Lion
     * In other words, a new born baby of Lion
     * @param field The field that it will be born to
     * @param loc the Location of the field
     */
    protected Animal getAnimal(Field field, Location loc)
    {
       Lion young = new Lion(false, field, loc, super.randomGender(),false);
       return young;
    } 
}

