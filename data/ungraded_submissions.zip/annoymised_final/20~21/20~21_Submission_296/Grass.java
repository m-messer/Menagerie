import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * This class represents characteristic of a Grass.
 * A simple model of Grass
 *
 * 
 * @version 2021.03.01
 */
public class Grass extends Plant
{
    // instance variables - replace the example below with your own
    private static final double HEIGHT_GROWTH_RATE = 1.75;
    private static final Random rand = Randomizer.getRandom();
    private static final double NEWPLANT_PROBABILITY = 0.1;
    private static final int MaxNewGrass = 1;
    private static final int GRASS_FOOD_VALUE= 45;

    /**
     * Constructor for objects of class Grass
     */
    public Grass(Field field, Location location)
    {
        super(field, location);
        height = 1.0;
    }
    
    /**
     * @return HEIGHT_GROWTH_RATE, the grow rate in term of height for grass
     */
    protected double getHeightGrowthRate()
    {
        return HEIGHT_GROWTH_RATE;
    }
    
    /**
     * @return NEWPLANT_PROBABILITY, the chance that new plant will be born
     */
    protected double getNewPlantProbability()
    {
        return NEWPLANT_PROBABILITY;
    }
    
    /**
     * @return MaxNewTree, the maximum grass that can be born per step
     */
    protected int getMaxNewPlant()
    {
        return MaxNewGrass;
    }
    
    /**
     * @return GRASS_FOOD_VALUE The value that a prey that eat the grass
     * will consumed and be added to the prey's food level
     */
    protected int getFoodValue()
    {
        return GRASS_FOOD_VALUE;
    }
    
}