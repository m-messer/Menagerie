import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * This class represents characteristic of a Alligator.
 * A simple model of Alligator
 * Alligators sleep at day time
 * Alligators eat preys only
 * Alligators age, move, breed, and die.
 *
 * 
 * @version 2021.03.01
 */
public class Alligator extends Predator
{
    // instance variables - replace the example below with your own
    // Characteristics shared by all Lions (class variables).

    // The age at which a Lion can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a Lion can live.
    private static final int MAX_AGE = 800; 
    // The likelihood of a Lion breeding.
    private static final double BREEDING_PROBABILITY = 0.1;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 3;
    // The food value of a single animal. In effect, this is the
    // number of steps a Lion can go before it has to eat again.
    private static final int MAX_FOOD_LEVEL = 120;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Constructor for objects of class Alligator
     */
    public Alligator(boolean randomAge, Field field, Location location,boolean gender, boolean haveDisease)
    {
        super(randomAge,field, location,gender,haveDisease);
        
    }
    
    /**
     * This is what the Alligator does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * Alligator sleep at day
     * @param field The field currently occupied.
     * @param newAlligators A list to return newly born Alligators.
     */
    public void act(List<LivingThing> newAlligators)
    {
       super.incrementAge();
       //check if they got disease
       super.checkDisease();
        
       //hunt in night time
       if (nightTime()){
             super.incrementHunger();
            if(isAlive()) {
                super.mating(newAlligators); 
                // Move towards a source of food if found.
                Location newLocation = super.findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
       }
       //otherwise, all alligator sleeps at day time
    }

    /**
     * @return MAX_AGE, max age of Alligator
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }
    
    /**
     * @return BREEDING_PROBABILITY , breeding probability of Alligator
     * In other words, chance of it giving new born Alligator
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }
    
    /**
     * @return MAX_LITTER_SIZE, max litter size of Alligator when
     * giving birth while mating
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }
    
    /**
     * @return BREEDING_AGE, age Alligator has to reached before
     * it can breed
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    
    /**
     * @return foodLevel, food level of this animal. In effects,
     * the step Alligator has left before it has to eat again
     */
    protected int getFoodLevel()
    { 
        return foodLevel;
    }
    
    /**
     * @return MAX_FOOD_LEVEL, max food level of Alligator
     */
    protected int getMaxFoodLevel()
    {
        return MAX_FOOD_LEVEL;
    }
    
    /**
     * @return haveDisease The status of this Alligator having
     * disease or not
     */
    protected boolean getAnimalDisease()
    {
        return haveDisease;
    }
    
    /**
     * Create new instance of Alligator
     * In other words, a new born baby of Alligator
     * @param field The field that it will be born to
     * @param loc the Location of the field
     */
    protected Animal getAnimal(Field field, Location loc)
    {
       Alligator young = new Alligator(false, field, loc, super.randomGender(),false);
       return young;
    }
}
