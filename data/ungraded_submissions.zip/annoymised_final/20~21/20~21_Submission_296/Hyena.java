import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * This class represents characteristic of a Hyena.
 * A simple model of Hyena
 * Hyenas hibernate in Winter
 * Hyenas eat preys only
 * Hyenas age, move, breed, and die.
 *
 * 
 * @version 2021.03.01
 */
public class Hyena extends Predator
{
    // Characteristics shared by all foxes (class variables).

    // The age at which a fox can start to breed.
    private static final int BREEDING_AGE = 4;
    // The age to which a fox can live.
    private static final int MAX_AGE = 130;
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 0.0425; 
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a fox can go before it has to eat again.
    private static final int MAX_FOOD_LEVEL = 40;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();

    /**
     * Create a Hyena. A Hyena can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Hyena will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Hyena(boolean randomAge, Field field, Location location,boolean gender,boolean haveDisease)
    {
        super(randomAge, field, location,gender,haveDisease);
    }

    /**
     * This is what the Hyena does most of the time: it hunts for
     * prey. In the process, it might breed, die of hunger,
     * or die of old age.
     * Hyena hibernates in Winter
     * @param field The field currently occupied.
     * @param newHyenas A list to return newly born Hyenas.
     */
    public void act(List<LivingThing> newHyenas)
    {
        super.incrementAge();
        //check if they got disease
        super.checkDisease();
        
        if(!hibernation()){
         super.incrementHunger();
          if(isAlive()) {
              super.mating(newHyenas);  
                // Move towards a source of food if found.
                Location newLocation = super.findFood();
                if(newLocation == null) { 
                    // No food found - try to move to a free location.
                    newLocation = getField().freeAdjacentLocation(getLocation());
                }
                // See if it was possible to move.
                if(newLocation != null) {
                    setLocation(newLocation);
                }
                else {
                    // Overcrowding.
                    setDead();
                }
            }
         }
    }

    /**
     * @return MAX_AGE, max age of Hyena
     */
    protected int getMaxAge()
    {
        return MAX_AGE;
    }

    /**
     * @return BREEDING_PROBABILITY , breeding probability ofHyena
     * In other words, chance of it giving new born Hyena
     */
    protected double getBreedingProbability()
    {
        return BREEDING_PROBABILITY;
    }

    /**
     * @return MAX_LITTER_SIZE, max litter size of Hyena when
     * giving birth while mating
     */
    protected int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    /**
     * @return BREEDING_AGE, age Hyena has to reached before
     * it can breed
     */
    protected int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * @return true, if Hyena hibernates
     */
    private boolean hibernation() {
        if(winter.getSeason() && rand.nextBoolean()) {
            return true;
        }
        else { 
            return false;
        }
    }

    /**
     * @return foodLevel, food level of Hyena. In effects,
     * the step Hyena has left before it has to eat again
     */
    protected int getFoodLevel()
    {
        return foodLevel;
    }

    /**
     * @return MAX_FOOD_LEVEL, max food level of Hyena
     */
    protected int getMaxFoodLevel()
    {
        return MAX_FOOD_LEVEL;
    }

    /**
     * @return haveDisease The status of this Hyena having
     * disease or not
     */
    protected boolean getAnimalDisease()
    {
        return haveDisease;
    }

    /**
     * Create new instance of Hyena
     * In other words, a new born baby of Hyena
     * @param field The field that it will be born to
     * @param loc the Location of the field
     */
    protected Animal getAnimal(Field field, Location loc)
    {
        Hyena young = new Hyena(false, field, loc, super.randomGender(),false);
        return young;
    }
}
