import java.util.Iterator;
import java.util.List;
import java.util.Random;
/**
 * A class representing shared characteristics of plants.
 * Plants can grow in height 
 * Plant can germinate to surrounding to give new born plant
 * Plant is directly affected by weather and season
 *
 * 
 * @version 2021.03.01
 */
public abstract class Plant extends LivingThing
{
    protected Weather rain = new Rain();
    protected Weather sun = new Sunny();
    private static final Random rand = Randomizer.getRandom();
    //height measured in inches
    protected double height;

    /**
     * Constructor for objects of class Plant
     */
    public Plant(Field field, Location location)
    {
        super(field, location);
    }

    public void act(List<LivingThing> newPlants)

    {
        //Check the weather and the consequences of it
        weather();
        if(isAlive()) {
            //if it is day time
            if (Time.dayTime())
            {
            newGrow(newPlants);
            if (sunnyDay())
            {
                //Jungle could burn
                JungleSunBurn();
                //new grow plant, double the rate of growing
                newGrow(newPlants);
            }
            }
        }
    }
  
    /**
     * Check what weather is it and the consequence follows
     */
    protected void weather()
    {

        if (rain.getWeather())
        {
            isRain();
        }
        else if (sun.getWeather()){
            isSun();
        }

    }

    /**
     * This plant might die if rains
     */
    private void isRain()
    {
        if (rain.loseLife() && (rain.getMeasureUnit() > 40))
        {
            setDead();
        }
    }

    /**
     * This plant grows
     */
    private void isSun()
    {
        height = height * getHeightGrowthRate();    
    }

    /**
     * @return if sunny weather is true/false
     * True, if the weather is sunny
     */
    protected boolean sunnyDay()
    {
        return sun.getWeather();
    }

    /**
     * If above 37 degrees, plant dead. 
     * Overheating
     */
    protected void JungleSunBurn()
    {
        if (sun.getMeasureUnit() > 37)
        {
            setDead();
        }
    }

    /**
     * @return height The height of the plant
     */
    public double getHeight()
    {
        return height;
    }

    /**
     * Generate a number representing the number of new plant,
     * if it have a chance to grow.
     * @return The number of new plant (may be zero).
     */
    private void newGrow(List<LivingThing> newPlants)
    {
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int babyPlant = growingProbability();
        for(int b = 0; b < babyPlant && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Plant baby = new Grass(field, loc);
            newPlants.add(baby);
        }
    }

    /**
     * Check whether or not this plant is to spread seed for
     * new plant at this step.
     * New plant will be made into free adjacent locations.
     * @param newBorn animal A list to return newly born plant.
     */
    private int growingProbability()
    {
        int babyPlant = 0;
        if (rand.nextDouble() <= getNewPlantProbability())
        {
            babyPlant = rand.nextInt(getMaxNewPlant()) + 1;
        }
        return babyPlant;
    }

    /**
     * Get the height of the plant
     */
    abstract protected double getHeightGrowthRate();

    /**
     * Get the probability of a chance a new plant can be born
     */
    abstract protected double getNewPlantProbability();

    /**
     * Get the maximum new plant that a plant give birth to
     */
    abstract protected int getMaxNewPlant();
    
    /**
     * Get the food value of the plant
     */
    abstract protected int getFoodValue();

}