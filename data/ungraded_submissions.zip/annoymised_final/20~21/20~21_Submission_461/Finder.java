import java.util.List;
import java.util.Iterator;
/**
  * Finder class - a class to be used in the simulation to find organisms
                  nearby a location. This class will return a requested object
                  of a class. For example if a wolf is trying to find a rat
                  this class will search for a rat and return the rat object.
 *
 * @version (a version number or a date)
 */
public class Finder
{
    // the field of the current organism
    private Field field;
    // location of the current organism on the field
    private Location location;

    /**
     * Constructor for objects of class Finder
     * @param organismField - field the organism is in
     * @param organismLocations - the location of the organism
     */
    public Finder(Field organismField,Location organismLocations)
    {
        field = organismField;
        location = organismLocations;
    }

    /**
     * This method finds a coyote in adjacent locations.
     *
     * @return object of the Coyote class found in an adjacent locations
     * @return null if coyote cannot be found
     */
    public Coyote findCoyote()
    {
        // retrieve a list of all locations near the current organism
        List<Location> adjacent = field.adjacentLocations(location);
        Iterator<Location> it = adjacent.iterator();
        // While loop to iterate through the list of locations
        while(it.hasNext()) {
            // each individual location in the list will be assigned to 'where'
            Location where = it.next();
            // retrieve object at the location and assign it to an object
            Object animal = field.getObjectAt(where);
            // check if the object is an instance of the Coyote class
            if(animal instanceof Coyote) {
                // change the object to an object of the Coyote class 
                Coyote coyote = (Coyote) animal;
                // return the coyote found
                return coyote;
            }
        }
        // coyote couldn't be found nearby 
        return null;
    }

    /**
     * This method finds a wolf in adjacent locations.
     *
     * @return object of the Wolf class found in an adjacent locations
     * @return null if wolf cannot be found
     */
    public Wolf findWolf()
    {
        // retrieve a list of all locations near the current organism
        List<Location> adjacent = field.adjacentLocations(location);
        Iterator<Location> it = adjacent.iterator();
        // While loop to iterate through the list of locations
        while(it.hasNext()) {
            // each individual location in the list will be assigned to 'where'
            Location where = it.next();
            // retrieve object at the location and assign it to an object
            Object animal = field.getObjectAt(where);
            // check if the object is an instance of the Wolf class
            if(animal instanceof Wolf) {
                // change the object to an object of the Wolf class 
                Wolf wolf = (Wolf) animal;
                // return the wolf found
                return wolf;
            }
        }
        // wolf couldn't be found nearby 
        return null;
    }

    /**
     * This method finds a Guinea Pig in adjacent locations.
     *
     * @return object of the GuineaPig class found in an adjacent locations
     * @return null if Guinea Pig cannot be found
     */
    public GuineaPig findGuineaPig()
    {
        // retrieve a list of all locations near the current organism
        List<Location> adjacent = field.adjacentLocations(location);
        Iterator<Location> it = adjacent.iterator();
        // While loop to iterate through the list of locations
        while(it.hasNext()) {
            // each individual location in the list will be assigned to 'where'
            Location where = it.next();
            // retrieve object at the location and assign it to an object
            Object animal = field.getObjectAt(where);
            // check if the object is an instance of the GuineaPig class
            if(animal instanceof GuineaPig) {
                // change the object to an object of the GuineaPig class 
                GuineaPig pig = (GuineaPig) animal;
                // return the GuineaPig found
                return pig;

            }
        } 
        // GuineaPig couldn't be found nearby 
        return null;
    }

    /**
     * This method finds a deer in adjacent locations.
     *
     * @return object of the Deer class found in an adjacent locations
     * @return null if deer cannot be found
     */
    public Deer findDeer()
    {
        // retrieve a list of all locations near the current organism
        List<Location> adjacent = field.adjacentLocations(location);
        Iterator<Location> it = adjacent.iterator();
        // While loop to iterate through the list of locations
        while(it.hasNext()) {
            // each individual location in the list will be assigned to 'where'
            Location where = it.next();
            // retrieve object at the location and assign it to an object
            Object animal = field.getObjectAt(where);
            // check if the object is an instance of the Deer class
            if(animal instanceof Deer) {
                // change the object to an object of the Deer class 
                Deer deer = (Deer) animal;
                // return the deer found
                return deer;

            }
        } 
        // deer couldn't be found nearby 
        return null;
    }

    /**
     * This method finds a plant in adjacent locations.
     *
     * @return object of the Plant class found in an adjacent locations
     * @return null if plant cannot be found
     */
    public Plant findPlant(){
        // retrieve a list of all locations near the current organism
        List<Location> adjacent = field.adjacentLocations(location);
        Iterator<Location> it = adjacent.iterator();
        // While loop to iterate through the list of locations
        while(it.hasNext()) {
            // each individual location in the list will be assigned to 'where'
            Location where = it.next();
            // retrieve object at the location and assign it to an object
            Object plant = field.getObjectAt(where);
            // check if the object is an instance of the Plant class
            if(plant instanceof Plant) {
                // change the object to an object of the Plant class 
                Plant plants = (Plant) plant;
                // return the plant found
                return plants;

            }
        } 
        // plant couldn't be found nearby 
        return null;
    }
    
    
    public Animal findAnimal(){
        // retrieve a list of all locations near the current organism
        List<Location> adjacent = field.adjacentLocations(location);
        Iterator<Location> it = adjacent.iterator();
        // While loop to iterate through the list of locations
        while(it.hasNext()) {
            // each individual location in the list will be assigned to 'where'
            Location where = it.next();
            // retrieve object at the location and assign it to an object
            Object plant = field.getObjectAt(where);
            // check if the object is an instance of the Plant class
            if(plant instanceof Animal) {
                // change the object to an object of the Plant class 
                Animal plants = (Animal) plant;
                // return the plant found
                return plants;

            }
        } 
        // plant couldn't be found nearby 
        return null;
    }
}
