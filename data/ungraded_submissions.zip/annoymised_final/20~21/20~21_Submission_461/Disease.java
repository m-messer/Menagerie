
/**
 * Disease class - a class to be used in the simulation to simulate a disease
                   outbreak as well as have a countdown timer for a random 
                   disease outbreak
 *
 * @version (a version number or a date)
 */
public class Disease extends Environment
{
    // the current condition of the disease (if it is active or not)
    private boolean disease;
    // the disease countdown timer
    private int diseaseTime;
    // number of animals with the disease
    private int diseaseCount;

    /**
     * This method changes the disease outbreak based on a random boolean 
     * generator
     * this method calls a method from the super class to generate a random
     * boolean value
     */
    public void ChangeDisease()
    {
        // retrieve random boolean value
        disease = super.getRandom().nextBoolean();

    }

    /**
     * This method returns a boolean value to indicate that the disease is 
     * active.
     * The boolean value is based on the random number generated in the
     * ChangeDisease() method
     * 
     * @return Boolean value true if disease outbreak is active
     */
    public boolean getDisease(){
        return disease;
    }

    /**
     * @Override
     * Method override (Chapter 11)
     * This method increments the time used for the countdown of the disease
     * outbreak
    */
    public void incrementTime(){
        diseaseTime++;
    }

    /**
     * @Override
     * Method override (Chapter 11)
     * This method returns a timer for the disease countdown
     * 
     * @return Integer value of the disease countdown timer
    */
    public int getTime(){
        return diseaseTime;

    }

    /**
     * @Override
     * Method override (Chapter 11)
     * 
     * this method resets the time variable to indicate the disease outbreak
     * condition has changed  
     */
    public void resetTime(){
        // resets disease countdown to indicate that a disease outbreak is active/non active
        diseaseTime = 0;
    }

    /**
     * this method increments the disease counter to indicate the number of 
     * animals that have the disease
     */
    public void increaseDiseaseCount(){
        // animal has caught the disease therefore the disease count increases
        diseaseCount++;
    }

    /**
     * this method decrements the disease counter to indicate an animal has 
     * been cured/died from the disease
     */
    public void decreaseDiseaseCount(){
        // decrements disease count 
        diseaseCount--;
        // if disease count goes negative then disease count stays as 0
        if (diseaseCount < 1 ){
            diseaseCount =0;
        }
    }

    /**
     * This method returns the counter for the number of animals that have 
     * the disease
     * 
     * @return Integer value of the disease counter
    */
    public int getDiseaseCount(){
        return diseaseCount;   
    }
    
    /**
     * This method resets the counter to indicate the simulation has been reseted
     * 
     * @return Integer value of the disease counter
    */
    public void resetDiseaseCount(){
        diseaseCount = 0;   
    }
}
