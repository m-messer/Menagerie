/**
  * Wolf class - a class to be used in the simulation to simulate
                  wolves. This class will have all the unique features of a 
                  wolf for example every wolf can compete with coyotes.
 *
 * @version 2016.02.29 (2)
 */
public class Wolf extends Predator
{
    
    // Breeding age for a wolf to start breeding 
    private static final int BREEDING_AGE = 70;
    // maximum age a wolf can live up to
    private static final int MAX_AGE = 200;
    // the probability of a wolf winning against a coyote
    private static final double WOLF_WIN_PROB = 0.5;
    // constant: default breeding probability for all wolf
    private static final double DEFAULT_BREEDING_PROBABILITY = 0.25;
    // the breeding probability that can change with each wolf
    private static  double breedingProbability = DEFAULT_BREEDING_PROBABILITY;
    // the maximum litter size of each wolf
    private static final int MAX_LITTER_SIZE = 2;

    /**
     * Create a Coyote. A Coyote can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the Coyote will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     * @param location The simulation the wolf is in 
     */
    public Wolf(boolean randomAge, Field field, Location location,Simulator simulation)
    {
        super(randomAge,field, location,simulation);
    }
    
    /**
     * This method returns the breeding age of a wolf
     * 
     * @return Integer value of the wolf breeding age
     */
    public int getBreedingAge(){
        return BREEDING_AGE;
    }
    
    /**
     * This method returns the maximum age of a wolf
     * 
     * @return Integer value of the wolf maximum age
     */
    public int getMaxAge(){
        return MAX_AGE;
    }
    
     /**
     * This method returns the breeding probability of a wolf
     * 
     * @return Double value of the coyote breeding probability
     */
    public double getBreedingProbability(){
        return breedingProbability;
    }
    
    /**
     * This method returns the maximum litter size of a coyote
     * 
     * @return Integer value of the wolf maximum litter size
     */
    public int getMaxLitterSize(){
        return MAX_LITTER_SIZE;
    }

    /**
     * This method will change the breeding probability of the wolf depending
     * on the weather condition and if the wolf is diseased
     * 
     * @param Integer value to indicate the weather condition
     */
    public void changeBreedingProbability(int weather){
        // check if weather is raining and if the wolf is diseased
        if (weather == 1|| getDisease()){
                // divide breeding by 3 because raining lower breeding probability
                breedingProbability /= 3;
        }
        // check if weather is hot
        if (weather == 0){
                // hot weather increases breeding probability
                breedingProbability *= 3;
        }
        // if the weather is anything else then the probability would be default
        else{
            setBreedingDefault();
        }
    }
    
    /**
     * This method will change the breeding probability of the wolf back to 
     * its default probability
     */
    protected void setBreedingDefault(){
        // breeding proability resets back to default
        breedingProbability = DEFAULT_BREEDING_PROBABILITY ;
    }
    
    /**
     * Look for coyotes adjacent to the current location.
     * Only the first live coyote is killed.
     * @param object of Finder class to be used to find a coyote
     * @return Where coyote was found, or null if it wasn't.
     */
    public Location compete(Finder find)
    {
        // find coyote in the area
        Coyote coyote = find.findCoyote();
        // check if coyote exist
        if(coyote != null ){
          // check if coyote is alive
            if(coyote.isAlive() && getRandom().nextDouble() <=WOLF_WIN_PROB ) { 
            // check if conditions are satisfied
            // check if wolf is diseased
            if (coyote.getDisease()&& !this.getDisease()){
                 // change current wolf to be diseased    
                this.changeDisease();
             }else if (coyote.getDisease()&& this.getDisease()){
                    // predator catches diseased
                    this.changeDisease();
                    getSimulation().decreaseCount();
                }
             //kill the coyote
            coyote.setDead();
            // return the location of the coyote for the wolf new location
            return coyote.getLocation();
          }
        }
        // find common food eaten by predators
        return super.preyFood(find);
    }
    
    /**
     * This method returns a new object of a Wolf class
     * 
     * @return object of the Wolf class
     */
    public Animal getNewAnimal(Field field,Location location){
        // returns a new object of the Wolf class for breeding
        return new Wolf(false, field, location,super.getSimulation());
    }
}