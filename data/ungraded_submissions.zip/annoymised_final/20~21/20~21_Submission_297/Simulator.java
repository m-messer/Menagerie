import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator {
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;

    // The probability that a mouse will be created in any given grid position.
    private static final double MOUSE_CREATION_PROBABILITY = 0.12;
    // The probability that a sheep will be created in any given grid position.
    private static final double SHEEP_CREATION_PROBABILITY = 0.12;
    // The probability that a bear will be created in any given grid position.
    private static final double BEAR_CREATION_PROBABILITY = 0.035;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.043;
    // The probability that a deer will be created in any given grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.14;
    // The probability that a grass will be created in any given grid position.
    private static final double GRASS_CREATION_PROBABILITY = 0.6;
    // The probability that a pumpkin will be created in any given grid position.
    private static final double PUMPKIN_CREATION_PROBABILITY = 0.7;
    // The probability that an animal is born infected
    private static final double BORN_INFECTED_PROBABILITY = 0.01;

    // List of animals in the field.
    private List<Animal> animals;

    // List of plants in the field
    private List<Plant> plants;

    // List of weather teritories in the field
    private List<Weather> weathers;

    // The current state of the field.
    private Field field;

    // The current statistics of the species in the field
    private FieldStats stats;

    // The current step of the simulation.
    private int step;

    // Flag that shows if all the animals have died
    private boolean animalsAlive;

    // A graphical view of the simulation.
    private SimulatorView view;

    // A graphical view of the statistics of the populations
    private GraphView graphView;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator() {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);

    }

    /**
     * Main method where all the tests were done
     *
     * @param args
     */
    public static void main(String[] args) {
        Simulator simulator = new Simulator(125, 125);
        simulator.simulate(500);
    }

    /**
     * Create a simulation field with the given size.
     *
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width) {
        // The code which starts a Thread and opends the GraphView view
        // is taken and modified from this source:
        // https://stackoverflow.com/questions/25873769/launch-javafx-application-from-another-class
        new Thread() {
            @Override
            public void run() {
                javafx.application.Application.launch(GraphView.class);
            }
        }.start();
        graphView = GraphView.waitForGraphView();

        if (width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        plants = new ArrayList<>();
        weathers = new ArrayList<>();
        field = new Field(depth, width);
        stats = new FieldStats();

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width, stats);
        view.setColor(Sheep.class, new Color(255, 64, 204, 100));
        view.setColor(Mouse.class, new Color(255, 96, 64, 100));
        view.setColor(Bear.class, Color.black);
        view.setColor(Wolf.class, new Color(87, 9, 0, 100));
        view.setColor(Deer.class, new Color(120, 105, 255, 100));
        view.setColor(Grass.class, new Color(212, 255, 105, 100));
        view.setColor(Pumpkin.class, new Color(255, 188, 105, 100));
        view.setColor(ClearSky.class, new Color(130, 251, 255, 90));
        view.setColor(Rain.class, new Color(82, 142, 255, 90));
        view.setColor(Cloud.class, new Color(156, 155, 152, 90));

        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation() {
        simulate(4000);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     *
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps) {
        for (int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            // delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep() {

        step++;
        TimeCycle.increaseTimeStep();

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();
        List<Plant> newPlants = new ArrayList<>();
        List<Weather> newWeathers = new ArrayList<>();
        // Let all rabbits act.
        for (Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals);
            if (!animal.isAlive()) {
                it.remove();
            }
        }
        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);

        for (Iterator<Plant> it = plants.iterator(); it.hasNext(); ) {
            Plant plants = it.next();
            plants.act(newPlants);
            if (!plants.isAlive()) {
                it.remove();
            }
        }

        // Add the newly created plants to the main lists.
        plants.addAll(newPlants);

        for (Iterator<Weather> it = weathers.iterator(); it.hasNext(); ) {
            Weather weathers = it.next();
            weathers.act(newWeathers);
            if (!weathers.isAlive()) {
                it.remove();
            }
        }

        // Add the newly appeared weathers to the main lists.
        weathers.addAll(newWeathers);

        view.showStatus(step, field);

        //Add the new statistics to the graphs
        if (animalsAlive || animals.size() > 0) {
            graphView.addPopulationData(step, stats.getPopulationByKey(Mouse.class), stats.getPopulationByKey(Sheep.class),
                    stats.getPopulationByKey(Deer.class), stats.getPopulationByKey(Bear.class), stats.getPopulationByKey(Wolf.class));
            if (stats.getPopulationByKey(Mouse.class) != 0 && stats.getPopulationByKey(Sheep.class) != 0 && stats.getPopulationByKey(Deer.class) != 0
                    && stats.getPopulationByKey(Bear.class) != 0 && stats.getPopulationByKey(Wolf.class) != 0) {
                animalsAlive = false;
            }
        }

        if (Virus.getCurrentInfectedCount() > 0) {
            graphView.addVirusData(step, Virus.getCurrentInfectedCount(), Virus.getTotalInfectedCount(), Virus.getDeathCount());
        }

        graphView.addPlantData(step, stats.getPopulationByKey(Grass.class), stats.getPopulationByKey(Pumpkin.class));
        graphView.addWeatherData(step, stats.getPopulationByKey(ClearSky.class), stats.getPopulationByKey(Rain.class), stats.getPopulationByKey(Cloud.class));
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset() {
        step = 0;
        animals.clear();
        plants.clear();
        weathers.clear();
        populate();
        TimeCycle.resetTime();

        // Show the starting state in the view.
        view.showStatus(step, field);
    }

    /**
     * Randomly populate the field with foxes and rabbits.
     */
    private void populate() {
        Random rand = Randomizer.getRandom();
        field.clear();
        for (int row = 0; row < field.getDepth(); row++) {
            for (int col = 0; col < field.getWidth(); col++) {
                if (rand.nextDouble() <= MOUSE_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, 1);
                    Mouse fox = new Mouse(true, field, location);
                    bornInfected(fox);
                    animals.add(fox);
                } else if (rand.nextDouble() <= SHEEP_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, 1);
                    Sheep sheep = new Sheep(true, field, location);
                    bornInfected(sheep);
                    animals.add(sheep);
                } else if (rand.nextDouble() <= BEAR_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, 1);
                    Bear bear = new Bear(true, field, location);
                    bornInfected(bear);
                    animals.add(bear);
                } else if (rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, 1);
                    Wolf wolf = new Wolf(true, field, location);
                    bornInfected(wolf);
                    animals.add(wolf);
                } else if (rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, 1);
                    Deer deer = new Deer(true, field, location);
                    bornInfected(deer);
                    animals.add(deer);
                }

                if (rand.nextDouble() <= GRASS_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, 0);
                    Grass grass = new Grass(true, field, location);
                    plants.add(grass);
                } else if (rand.nextDouble() <= PUMPKIN_CREATION_PROBABILITY) {
                    Location location = new Location(row, col, 0);
                    Pumpkin pumpkin = new Pumpkin(true, field, location);
                    plants.add(pumpkin);
                }

                int randWeatherInt = rand.nextInt(3);
                if (randWeatherInt == 0) {
                    Location location = new Location(row, col, 2);
                    Rain rain = new Rain(field, location);
                    weathers.add(rain);
                } else if (randWeatherInt == 1) {
                    Location location = new Location(row, col, 2);
                    Cloud cloud = new Cloud(field, location);
                    weathers.add(cloud);
                } else if (randWeatherInt == 2) {
                    Location location = new Location(row, col, 2);
                    ClearSky clearSky = new ClearSky(field, location);
                    weathers.add(clearSky);
                }
                // else leave the location empty.
            }
        }
        animalsAlive = true;
    }


    /**
     * At the beginning of the simulation this method decide the patient zeros for the virus
     *
     * @param animal The newly created/spawned animal
     */
    private void bornInfected(Animal animal) {
        Random rand = Randomizer.getRandom();
        if (rand.nextDouble() <= BORN_INFECTED_PROBABILITY) {
            animal.infected();
        }
    }

    /**
     * Pause for a given time.
     *
     * @param millisec The time to pause for, in milliseconds
     */
    private void delay(int millisec) {
        try {
            Thread.sleep(millisec);
        } catch (InterruptedException ie) {
            // wake up
        }
    }
}
