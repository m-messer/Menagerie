import java.util.List;

/**
 * This class represents the pumpkin plant specie in the simulation.
 * It defines the specific actions of the pumpkins such as multiplying and its
 * behaviour.
 * It specifies the fields of all pumpkins as well
 *
 * @version 01.03.2021
 */
public class Pumpkin extends Plant {

    // The age when the plant can start breeding
    private static final int BREEDING_AGE = 1;
    // Maximum age of the plant
    private static final int MAX_AGE = 30;
    // Probability of a plant to multiply
    private static final double BREEDING_PROBABILITY = 1;
    // The the number of new pumpkin created when multiplying
    private static final int SPREAD_SIZE = 4;
    // The food value of the plant when eaten
    private static final int FOOD_VALUE = 12;

    /**
     * Create a new pumpkin at location in field.
     *
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     * @param randomAge Flag whether the pumpkin can have randomly allocated age
     */
    public Pumpkin(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location, BREEDING_AGE, MAX_AGE, BREEDING_PROBABILITY, SPREAD_SIZE, FOOD_VALUE);
    }

    /**
     * It executes the actions that a pumpkin can do based on the given conditions
     *
     * @param newPumpkins A list to receive newly created Pumpkins.
     */
    @Override
    public void act(List<Plant> newPumpkins) {

        // Pumpkins grow during both the day and night
        grow();
        if (isAlive()) {
            multiply(newPumpkins);
        }
    }
    
    /**
     *
     * @param field The field currently occupied.
     * @param loc   The location within the field.
     * @return A new grass object
     */
    @Override
    public Plant createPlant(Field field, Location loc) {
        return new Pumpkin(false, field, loc);
    }
}
