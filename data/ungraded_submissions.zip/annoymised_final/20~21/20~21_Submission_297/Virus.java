/**
 * A class representing the virus that can spread on the field
 *
 * @version 2021.02.26
 */
public class Virus {

    // The current number of infected animals
    private static int currentInfectedCount;
    // The total numbers of infection
    private static int totalInfectedCount;
    // The number of dead animals caused by the virus
    private static int deathCount;
    // The probability that an animal dies because of infection
    private static final double DEATH_PROBABILITY = 0.1;
    // The probability of recovery
    private static final double RECOVER_PROBABILITY = 0.1;

    /**
     * Increments the  currentInfectedCount and totalInfectedCount
     */
    public static void increaseInfectedCount() {
        currentInfectedCount++;
        totalInfectedCount++;
    }

    /**
     * Check the number of animals infected currently and return it
     *
     * @return The number of animals infected currently
     */
    public static int getCurrentInfectedCount() {
        return currentInfectedCount;
    }

    /**
     * Check the number of dead animals caused by the virus and return it
     *
     * @return The number of dead animals caused by the virus
     */
    public static int getDeathCount() {
        return deathCount;
    }

    /**
     * Check the total numbers of infection and return it
     *
     * @return The total numbers of infection
     */
    public static int getTotalInfectedCount() {
        return totalInfectedCount;
    }

    /**
     * Decreases the currentInfectedCount
     */
    public static void decreaseInfectedCount() {
        currentInfectedCount--;
    }

    /**
     * Increments the deathCount
     */
    public static void increaseDeadCount() {
        deathCount++;
    }

    /**
     * Check the probability of death if an animal is infected and return it
     *
     * @return The probability of death if an animal is infected
     */
    public static double getDeathProbability() {
        return DEATH_PROBABILITY;
    }

    /**
     * Check the probability of recovery if an animal is infected and return it
     *
     * @return The probability of recovery if an animal is infected
     */
    public static double getRecoverProbability() {
        return RECOVER_PROBABILITY;
    }
}
