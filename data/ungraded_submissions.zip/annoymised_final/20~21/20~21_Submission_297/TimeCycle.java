/**
 * TimeCycle class keeps track of time in the simulation.
 * It is static because all the objects in the simulation
 * should have access to the same time values.
 *
 * @version 01.03.2021
 */
public class TimeCycle {

    // The current time passed since the start of the simulation
    private static int timeStep = 0;

    /**
     * Increments the timeStep by 1
     */
    public static void increaseTimeStep() {
        timeStep++;
    }

    /**
     * It resets the time to zero
     */
    public static void resetTime() {
        timeStep = 0;
    }

    /**
     * It indicates that whether it is morning or not
     *
     * @return true if the timeStep % 4 equals to 1, alias Morning
     */
    public static boolean getIsMorning() {
        return timeStep % 4 == 1;
    }

    /**
     * It indicates that whether it is noon or not
     *
     * @return true if the timeStep % 4 equals to 2, alias Noon
     */
    public static boolean getIsNoon() {
        return timeStep % 4 == 2;
    }

    /**
     * It indicates that whether it is afternoon or not
     *
     * @return true if the timeStep % 4 equals to 3, alias Afternoon
     */
    public static boolean getIsAfternoon() {
        return timeStep % 4 == 3;
    }

    /**
     * It indicates that whether it is night or not
     *
     * @return true if the timeStep % 4 equals to 0, alias Night
     */
    public static boolean getIsNight() {
        return timeStep % 4 == 0;
    }
}
