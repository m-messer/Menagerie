import java.util.List;

/**
 * A simple model of a rabbit.
 * Rabbits age, move, breed, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Rabbit extends Animal {
    // Characteristics shared by all rabbits (class variables).

    // The age to which a rabbit can live.
    static final int MAX_AGE = 50;
    // The age at which a rabbit can start to breed.
    private static final int BREEDING_AGE = 5;
    // The likelihood of a rabbit breeding.
    private static final double BREEDING_PROBABILITY = 0.5;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    private static final int FOOD_VALUE = 6;

    /**
     * Create a new rabbit. A rabbit may be created with age
     * zero (a new born) or with a random age.
     *
     * @param randomAge If true, the rabbit will have a random age.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     */
    public Rabbit(boolean randomAge, Field field, Location location) {
        super(randomAge, field, location, MAX_AGE, FOOD_VALUE);
    }

    @Override
    protected Creature birth(Field field, Location location) {
        return new Rabbit(false, field, location);
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     *
     * @return The number of births (may be zero).
     */
    protected int birthCount(int simulationStep) {
        int births = 0;
        if (canBreed() && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE + 1);
        }
        return births;
    }

    /**
     * A rabbit can breed if it has reached the breeding age.
     *
     * @return true if the rabbit can breed, false otherwise.
     */
    private boolean canBreed() {
        return age >= BREEDING_AGE;
    }

    @Override
    boolean isFood(Creature creature) {
        return creature instanceof Grass;
    }
}
