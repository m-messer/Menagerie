/**
 * A simple model of a fox.
 * Foxes age, move, eat rabbits, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Wolf extends Animal {
    // Characteristics shared by all foxes (class variables).

    // The age at which a fox can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a fox can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a fox breeding.
    private static final double BREEDING_PROBABILITY = 0.05;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // The food value of a single rabbit. In effect, this is the
    // number of steps a fox can go before it has to eat again.
    private static final int FOOD_VALUE = 8;
    // Simulator that runs the game.
    private final Simulator simulator;

    /**
     * Create a fox. A fox can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     *
     * @param randomAge If true, the fox will have random age and hunger level.
     * @param field     The field currently occupied.
     * @param location  The location within the field.
     * @param simulator Simulator that runs the game.
     */
    public Wolf(boolean randomAge, Field field, Location location, Simulator simulator) {
        super(randomAge, field, location, MAX_AGE, FOOD_VALUE);
        this.simulator = simulator;
    }

    /**
     * Generate a number representing the number of births,
     * if it can breed.
     *
     * @return The number of births (may be zero).
     * @param simulationStep The current step in the simulator.
     */
    protected int birthCount(int simulationStep) {
        int births = 0;
        boolean canBreed = age >= BREEDING_AGE;
        if (canBreed && rand.nextDouble() <= BREEDING_PROBABILITY) {
            births = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return births;
    }

    protected Creature birth(Field field, Location location) {
        return new Wolf(false, field, location, simulator);
    }

    public boolean isFood(Creature creature) {
        return creature instanceof Cow;
    }

    /**
     * Make this wolf more hungry. This could result in death.
     * 
     * @param by Decrease food level by the given value.
     */
    protected void increaseHunger(int by) {
        int time = simulator.getStep() % 24;
        if (time >= 20) { // Wolves are hungrier at night
            super.increaseHunger(by + 3);
        } else {
            super.increaseHunger(by);
        }
    }
}
