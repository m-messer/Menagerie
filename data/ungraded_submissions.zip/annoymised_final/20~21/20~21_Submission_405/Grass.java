import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * Write a description of class grass here.
 *
 * @version 2021.03.01 (5)
 */
public class Grass extends Animal
{
    // the grasses age.
    private int age;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    // The age to which grasss can live.
    private static final int MAX_AGE = 25;
    //
    private static final double GERMINATE_PROBABILITY = 0.8;
    //
    private static final int MAX_LITTER_SIZE = 10;
    //
    private static final int GERMINATE_AGE = 4;
    
    /**
     * 
     * Constructor for objects of class grass, the grass is either randonmly created at the start of the simulation or is a baby.
     */
    public Grass(boolean randomAge, Field field, Location location)
    {
        super(field, location);
        age = 0;   
        if(randomAge) {
            age = rand.nextInt(MAX_AGE);
        }
        else 
        {
            age = 0;
        }
    }

    /**
     * this is the method that allows the grass to act.
     */
    public void act(List<Animal> newGrass)
    {
        //incrementAge();
        if(isAlive()) {
            pollinate(newGrass);
            // Try to move into a free location.
            List<Location> adjacent = field.adjacentLocations(getLocation());
            Iterator<Location> it = adjacent.iterator();
        }
    }
    
    /**
     * Method that allows the grass to pollinate and reproduce
     */
    public void pollinate(List<Animal> newGrass)
    {
        // New grass are planted into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int germination = pollination();
        for(int b = 0; b < germination && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Grass young = new Grass(false, field, loc);
            newGrass.add(young);
        }
    }
    /**
     *  Allows to give the number of baby plants that will grow
     */
    public int pollination()
    {
        int germination = 0;
        if(canGerminate() && rand.nextDouble() <= GERMINATE_PROBABILITY) {
            germination = rand.nextInt(MAX_LITTER_SIZE) + 1;
        }
        return germination;
    }
    
    /**
     * checks if the grass is old enough to grow.
     */
    public boolean canGerminate()
    {
       return age >= GERMINATE_AGE;
    }
    
    public double getBreedingProbablity()
    {
        return GERMINATE_PROBABILITY;
    }

    public int getBreedingAge() 
    {
        return GERMINATE_AGE;
    }

    public int getMaxAge()
    {
        return MAX_AGE;
    } 
    
    public int getMaxLitterSize()
    {
        return MAX_LITTER_SIZE;
    }

    public Class getAnimalClass()
    {
        return Grass.class;
    }
    
    public Class getFirstFoodClass()
    {
        return null;
    }
    
    public Class getSecondFoodClass()
    {
        return null;
    }
    
    public int getFirstFoodValue()
    {
        return 0;
    }
    
    public int getSecondFoodValue()
    {
        return 0;
    }
    
    public boolean getFemale() 
    {
        return false;
    }
    
    public Animal getNewAnimal(boolean randomAge, Field field, Location location)
    {
        Grass newAnimal = new Grass(false, field, location);
        return newAnimal;
    }
    
    }