import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * containing rabbits and foxes.
 *
 * @version 2016.02.29 (2)
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    //an object of the class population generator. 
    private PopulationGenerator popGenerator = new PopulationGenerator();
    // List of actors in the field.
    private List<Actor> actors;
    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // A graphical view of the simulation.
    private SimulatorView view;
    //time
    private Time time; 
    // weather 
    private Weather weather;
    
    
    
    /**
     * Construct a simulation field with default size.
     */
    public Simulator(){
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
        weather = new Weather();
    }
    
    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width){
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }
        
        actors = new ArrayList<>();
        field = new Field(depth, width);
        time = new Time();
        weather = new Weather();
        
        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        popGenerator.setColors();
        
        // Setup a valid starting point.
        reset();
    }
    
    /**
     * Run the simulation from its current state for a reasonably long period,
     * (4000 steps).
     */
    public void runLongSimulation(){
        simulate(4000);
    }
    
    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps){
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            time.incrementTime();
            if(time.isNight()){
                weather.setRandomWeather();
            }
            simulateOneStep();
            delay(60);   // uncomment this to run more slowly
        }
    }
    
    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each
     * fox and rabbit.
     */
    public void simulateOneStep(){
        step++;
        time.incrementTime();
        if(time.isNight()){
            weather.setRandomWeather();
        }
        // Provide space for newborn actors.
        List<Actor> newActor = new ArrayList<>();        
        // Let all rabbits act.
        for(Iterator<Actor> it = actors.iterator(); it.hasNext(); ) {
            Actor actor = it.next();
            popGenerator.setRestrictions(actor, newActor);
            
            if(! actor.isActive()) {
                it.remove();
            }
        }
               
        // Add the newly born actors to the main lists.
        actors.addAll(newActor);

        view.showStatus(step, field, time, weather);
    }
        
    /**
     * Reset the simulation to a starting position.
     */
    public void reset(){
        step = 0;
        time.restart(); 
        weather.setRandomWeather();
        actors.clear();
        popGenerator.populate();
        
        // Show the starting state in the view.
        view.showStatus(step, field, time, weather);
    }
    
    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec){
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }
    
    public class PopulationGenerator {
        // probability of creating carnivors (predators). 
        private static final double CARNIVORS_CREATION_PROBABILITY = 0.03;
        // probability of creating herbivores (preys). 
        private static final double HERBIVORS_CREATION_PROBABILITY = 0.07;
        // probability of creating plants. 
        private static final double PLANT_CREATION_PROBABILITY = 0.085;
        // probability of creating humnans. 
        private static final double HUMAN_CREATION_PROBABILITY = 0.004;

        /**
         * Randomly populate the field with animals humans and plants.
         */
        private void populate(){
            Random rand = Randomizer.getRandom();
            field.clear();
            for(int row = 0; row < field.getDepth(); row++) {
                for(int col = 0; col < field.getWidth(); col++) {
                    Location location = new Location(row, col);
                    int rnd = new Random().nextInt(2);
                    int rnd2 = new Random().nextInt(3);
                    if(rand.nextDouble() <= CARNIVORS_CREATION_PROBABILITY) {
                        if(rnd2 == 0){
                            actors.add(new Lion(false, field, location));
                        }
                        else if(rnd2 ==1){
                            actors.add(new Cheetah(false, field, location));
                        }
                        else{
                            actors.add(new Tiger(false, field, location));

                        } 
                    }
                    else if(rand.nextDouble() <= HERBIVORS_CREATION_PROBABILITY) {
                        if(rnd == 0){
                            actors.add(new Giraffe(false, field, location));
                        }
                        else if(rnd == 1){
                            actors.add(new Zebra(false, field, location));
                        }
                    }
                    else if(rand.nextDouble() <= PLANT_CREATION_PROBABILITY) {
                        if(rnd == 0){
                            actors.add(new Grass(false, field, location));
                        }
                        else if(rnd == 1){
                            actors.add(new Acacia(false, field, location));
                        }
                    }
                    else if(rand.nextDouble() <= HUMAN_CREATION_PROBABILITY) {
                        actors.add(new Hunter(field, location));
                    }
                    // else leave the location empty.
                }   
            }
        }
        /**
         * Create a view of the state of each location in the field. 
         */
        public void setColors(){
            view.setColor(Lion.class, Color.GRAY);
            view.setColor(Tiger.class, Color.BLACK); 
            view.setColor(Cheetah.class, Color.BLUE);        
            view.setColor(Giraffe.class, Color.ORANGE);
            view.setColor(Zebra.class, Color.CYAN);
            view.setColor(Grass.class, new Color(36, 220, 36));
            view.setColor(Acacia.class, new Color(100, 180, 100));
            view.setColor(Hunter.class, new Color(255, 84, 250));
        }
        /**
         * sets restrictions for each weather condition. 
         */
        public void setRestrictions(Actor actor, List<Actor> newActor){  
            if (time.isNight() || actor instanceof Plant){  // only grass grows at night. 
                actor.act(newActor);
            } 
            
            else if(weather.getCurrentWeather().equals(WeatherConditions.SNOWY.toString())
            && !(actor instanceof Hunter)){ // only hunters dont move in snowy weather 
                actor.act(newActor);
            }
            else{
                actor.act(newActor);
            }
        }
    }
}
