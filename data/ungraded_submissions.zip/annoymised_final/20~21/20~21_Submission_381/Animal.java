import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal implements Actor
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The age of the animal.
    private int age;
    // The gender of the animal.
    private boolean isMale;
    // The food level of an animal, it is increased by eating
    private int foodLevel;
    //the life expectancy of an animal. 
    private int lifeExpectancy; 
    // boolean of weather an animal is infected with a disease or not. 
    private boolean isInfected; 
    // The infection disease.
    private Disease infectionSource;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    //a shared random number generator. 
    private static final Random rand = Randomizer.getRandom();
    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        age = 0;
        alive = true;
        if (rand.nextInt(2) ==1)
            isMale = true;
        else
            isMale = false;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Actor> newAnimals);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    public boolean isActive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    
    /**
     * returns tne age of the animal. 
     */
    protected int getAge(){
        return age;
    }
    
    /**
     * sets the animal's age to the age passed as a parameter. 
     */
    protected void setAge(int num){
        age = num;
    }
    
    /**
     * returns the maximum age an animal lives.
     */
    abstract protected int getMaxAge();
    
    /**
     * increments age by 1. 
     */
    protected void incrementAge(){
        setAge(getAge() + 1);
        if(getAge() > getMaxAge()) {
            setDead();
            System.out.println("Died of old age");
        }
    } 
    
    /**
     * indicates if an animal is a make or female 
     * @return: a boolean indicating if the animal is a male. 
     */
    protected boolean isMale()
    {
        return isMale;
    }
    
    /**
     * returns current food level of an animal. 
     */
    protected int getFoodLevel(){
        return foodLevel;
    }
	
    /**
     * set an animals current foodLevel
     * @param foodLevel int set the current foodLevel
     */
    protected void setFoodLevel(int level){
        foodLevel = level;
    } 
    
    /**
     * increments hunger by decrementing food level by 1. 
     */
    protected void incrementHunger()
    {
        setFoodLevel(getFoodLevel()  - 1);
        if(getFoodLevel() <= 0) {
            setDead();
            System.out.println("Died of hunger");
        }
    }
    
    /**
     * sets life expectancy of an animal to the passed parameter. 
     */
    protected void setLifeExpectancy(int num){ 
        lifeExpectancy = num; 
    } 
    
    /**
     * returns life expectancy of the animal. 
     */
    protected int getLifeExpectancy(){ 
        return lifeExpectancy; 
    }
    
    /**
     * decreases life expectancy of the animal. 
     */
    protected void decrementLifeExpectancy(){ 
        setLifeExpectancy(getLifeExpectancy() - 1);
        if(getLifeExpectancy() <= 0) {
            setDead();
            System.out.println("Died of infection");
        }
    } 
    
    /**
     * returns a boolean representing if the animal is infected or not. 
     */
    public boolean isInfected(){ 
        return isInfected; 
    } 
    
    /**
     * sets the variable isInfected to the passed parameter. 
     */
    public void setInfection(boolean infection){
        isInfected = infection;
    }
    
    /**
     * @returns the infection disease.
     */
    protected Disease getInfectionSource(){
        return infectionSource;
    }
    
    /**
     * sets the infection disease.
     */
    protected void setInfectionSource(Disease source){
        infectionSource = source;
    }
    
    /**
     * returns the maximum number of births
     */
    abstract protected int getMaxLitterSize();
    
    /**
     * returns the breeding probability. 
     */
    abstract protected double getBreedingProbability();
    
    /** 
     * Generate a number representing the number of births. 
     * if it can breed. 
     * @return the number of births (may be zero) 
     */
    protected int breed()
    {
        int births = 0;
        if(canBreed() && getRandom().nextDouble() <= getBreedingProbability()) {
            births = getRandom().nextInt(getMaxLitterSize()) + 1;
        }
        return births;
    }
    
    /**
     * returns the age at which an animal can breed. 
     * @return int representing age in hich an animal can breed. 
     */
    abstract protected int getBreedingAge();
    
    /**
     * returns an integer which represents the minimum food level that an animal can breed with. 
     */
    abstract protected int getBreedingFoodLevel();
    
    /**
     * An animal can breed if it has reached the breeding age.
     * @return true if the animal can breed, false otherwise.
     */
    protected boolean canBreed(){
        return getAge() >= getBreedingAge() && getFoodLevel() > getBreedingFoodLevel();
    }
    
    /**
     * Checks wheather or not this animal is to give births at this step
     * new births will be make into free adgacent locations.
     * @param the field and the current location of the animal
     */
    abstract protected Animal giveBirth(Field field, Location location);
    
    /**
     * checks if the animal at the adjacent location is of teh opposite gender to be able to mate or not. 
     */
    abstract protected boolean isMate(Location loc);
    
    /**
     * Check whether or not this animal is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newAnimals A list to return newly born animals.
     */
    protected void giveBirth(List<Actor> newAnimals)
    {
        // New giraffees are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            for ( Location loc : field.adjacentLocations(getLocation())){ 
                if (isMate(loc)){
                    Location location = free.remove(0);
                    newAnimals.add(giveBirth(field, location));
                    break;
                } 
            }
        }
    }
    
    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * returns the random number generated in this animal. 
     */
    protected Random getRandom(){
        return rand;
    }
}
