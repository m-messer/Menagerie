import java.util.List;
/**
 * A class representing shared characteristics of actors.
 *
 * @version (a version number or a date)
 */
public interface Actor
{
 /**
 * Perform the actor's regular behavior.
 * @param newActors A list for storing newly created
 * actors.
 */
 void act(List<Actor> newActors);
 
 /**
 * Is the actor still active?
 * @return true if still active, false if not.
 */
 boolean isActive();
 

 /**
 * Is the actor infected with a disease?
 * @return true if is infected, false if not.
 *
 boolean getInfectionStatus();
 
 *
 * 
 *
 Disease getDisease();
*/
}
