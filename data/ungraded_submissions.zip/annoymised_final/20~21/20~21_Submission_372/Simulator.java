import java.util.Random;
import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;
import java.awt.Color;

/**
 * A simple predator-prey simulator, based on a rectangular field
 * of a Jungle containing different kinds of animals.
 *
 * @version 2021.01.03
 */
public class Simulator
{
    // Constants representing configuration information for the simulation.
    // The default width for the grid.
    private static final int DEFAULT_WIDTH = 120;
    // The default depth of the grid.
    private static final int DEFAULT_DEPTH = 80;
    // The probability that a coyote will be created in any given grid position.
    private static final double COYOTE_CREATION_PROBABILITY = 0.04;
    // The probability that a rat will be created in any given grid position.
    private static final double RAT_CREATION_PROBABILITY = 0.05; 
    // The probability that a lion will be created in any given grid position.
    private static final double LION_CREATION_PROBABILITY = 0.02; 
    // The probability that a deer will be created in any given grid position.
    private static final double DEER_CREATION_PROBABILITY = 0.04;
    // The probability that a wolf will be created in any given grid position.
    private static final double WOLF_CREATION_PROBABILITY = 0.03;

    // List of animals in the field.
    private List<Animal> animals;
    //List of all locations in the field
    private List<Location> locations;
    //List of all diseases in the simulation
    private List<Disease> diseases;

    // The current state of the field.
    private Field field;
    // The current step of the simulation.
    private int step;
    // The current hour of the simulator
    private int hour;
    // A graphical view of the simulation.
    private SimulatorView view;
    // The weather of the simulator
    private Weather weather;

    /**
     * Construct a simulation field with default size.
     */
    public Simulator()
    {
        this(DEFAULT_DEPTH, DEFAULT_WIDTH);
    }

    /**
     * Create a simulation field with the given size.
     * @param depth Depth of the field. Must be greater than zero.
     * @param width Width of the field. Must be greater than zero.
     */
    public Simulator(int depth, int width)
    {
        if(width <= 0 || depth <= 0) {
            System.out.println("The dimensions must be greater than zero.");
            System.out.println("Using default values.");
            depth = DEFAULT_DEPTH;
            width = DEFAULT_WIDTH;
        }

        animals = new ArrayList<>();
        locations = new ArrayList<>();
        diseases = new ArrayList<>();
        field = new Field(depth, width);
        weather = new Weather();

        //Create different diseases for the animals
        Disease rabbies = new Disease("Rabbies", true, 0.005);
        diseases.add(rabbies);
        Disease anthrax = new Disease("Anthrax", true, 0.03);
        diseases.add(anthrax);
        Disease pox = new Disease("Pox", false, 0.01);   
        diseases.add(pox);

        // Create a view of the state of each location in the field.
        view = new SimulatorView(depth, width);
        view.setColor(Rat.class, Color.MAGENTA);
        view.setColor(Coyote.class, Color.BLUE);
        view.setColor(Lion.class, Color.ORANGE);
        view.setColor(Deer.class, Color.GREEN);
        view.setColor(Wolf.class, Color.RED);
        // Setup a valid starting point.
        reset();
    }

    /**
     * Run the simulation from its current state for a reasonably long period,
     * (500 steps).
     */
    public void runLongSimulation()
    {
        simulate(500);
    }

    public void run50()
    {
        simulate(50);
    }

    /**
     * Run the simulation from its current state for the given number of steps.
     * Stop before the given number of steps if it ceases to be viable.
     * @param numSteps The number of steps to run for.
     */
    public void simulate(int numSteps)
    {
        for(int step = 1; step <= numSteps && view.isViable(field); step++) {
            simulateOneStep();
            delay(60);   // uncomment this to run more slowly
        }
    }

    /**
     * Run the simulation from its current state for a single step.
     * Iterate over the whole field updating the state of each animal.
     */
    public void simulateOneStep()
    {
        step++;
        weather.setWeather();    

        if(step%5 ==0)  //hour increases after each 5 steps
        {
            incrementHour();   
            
            //Affects the animals with some disease
            for(Iterator<Disease> it = diseases.iterator(); it.hasNext(); ) {
                Disease disease = it.next();
                if(disease.animalAffectedOrNot()){
                    Random rand = new Random();
                    // The position of the animal to be affected in the list "animals".
                    int positionOfAnimalAffected = rand.nextInt(animals.size());
                    Animal animal = animals.get(positionOfAnimalAffected);
                    animal.affectAnimal(disease.getInfectious());
                }
            }
        }

        // Provide space for newborn animals.
        List<Animal> newAnimals = new ArrayList<>();  
        
        // Let all animals act.
        for(Iterator<Animal> it = animals.iterator(); it.hasNext(); ) {
            Animal animal = it.next();
            animal.act(newAnimals, hour, weather.getWeather());
            if(! animal.isAlive()) {
                it.remove();
            }
        }

        // Add the newly born animals to the main lists.
        animals.addAll(newAnimals);

        //Lets the grass at each location grow.
        for(Iterator<Location> it = locations.iterator(); it.hasNext(); ) {
            Location location = it.next();
            location.increaseGrassLength();
            // Grass grows quicket if the weather is Sunny or Rainy.
            if("Sunny".equals(weather.getWeather()) || "Rainy".equals(weather.getWeather())){
                location.increaseGrassLengthBy(2);
            }
        }

        view.showStatus(step, field, hour);
    }

    /**
     * Reset the simulation to a starting position.
     */
    public void reset()
    {
        step = 0;
        hour = 0;
        animals.clear();
        populate();

        // Show the starting state in the view.
        view.showStatus(step, field, hour);
    }

    /**
     * Randomly populate the field with different animals.
     */
    private void populate()
    {
        Random rand = Randomizer.getRandom();
        field.clear();
        for(int row = 0; row < field.getDepth(); row++) {
            for(int col = 0; col < field.getWidth(); col++) {

                Location location = new Location(row, col);
                locations.add(location);

                if(rand.nextDouble() <= COYOTE_CREATION_PROBABILITY) {
                    Coyote coyote = new Coyote(true, field, location);
                    animals.add(coyote);
                    coyote.setSex(rand.nextDouble());
                }

                else if(rand.nextDouble() <= WOLF_CREATION_PROBABILITY) {
                    Wolf wolf = new Wolf(true, field, location);
                    animals.add(wolf);
                    wolf.setSex(rand.nextDouble());
                }

                else if(rand.nextDouble() <= RAT_CREATION_PROBABILITY) {
                    Rat rat = new Rat(true, field, location);
                    animals.add(rat);
                    rat.setSex(rand.nextDouble());
                }

                else if(rand.nextDouble() <= LION_CREATION_PROBABILITY) {
                    Lion lion = new Lion(true, field, location);
                    animals.add(lion);
                    lion.setSex(rand.nextDouble());
                }

                else if(rand.nextDouble() <= DEER_CREATION_PROBABILITY) {
                    Deer deer = new Deer(true, field, location);
                    animals.add(deer);
                    deer.setSex(rand.nextDouble());
                }
            }
        }
    }

    /**
     * Pause for a given time.
     * @param millisec  The time to pause for, in milliseconds
     */
    private void delay(int millisec)
    {
        try {
            Thread.sleep(millisec);
        }
        catch (InterruptedException ie) {
            // wake up
        }
    }

    /**
     * Increment the value of hour by 1.
     */
    public void incrementHour() 
    {
        if(hour<23){
            hour++;
        }
        else{
            hour = 0;
        }
    }
}
