/**
 * Represent a location in a rectangular grid.
 *
 * @version 2021.01.03
 */
public class Location
{
    // Row and column positions.
    private int row;
    private int col;
    
    // Information about Grass.
    // The length of the grass.
    private int grassLength;
    // The maximum length grass can grow at each location.
    private int maxGrassLength = 5;
    // Indicates whether the grass is fully grown and ready to be eaten.
    private boolean fullyGrown;

    /**
     * Represent a row and column.
     * @param row The row.
     * @param col The column.
     */
    public Location(int row, int col)
    {
        this.row = row;
        this.col = col;
        grassLength = maxGrassLength;
        fullyGrown = true;
    }

    /**
     * Implement content equality.
     */
    public boolean equals(Object obj)
    {
        if(obj instanceof Location) {
            Location other = (Location) obj;
            return row == other.getRow() && col == other.getCol();
        }
        else {
            return false;
        }
    }

    /**
     * Return a string of the form row,column
     * @return A string representation of the location.
     */
    public String toString()
    {
        return row + "," + col;
    }

    /**
     * Use the top 16 bits for the row value and the bottom for
     * the column. Except for very big grids, this should give a
     * unique hash code for each (row, col) pair.
     * @return A hashcode for the location.
     */
    public int hashCode()
    {
        return (row << 16) + col;
    }

    /**
     * @return The row.
     */
    public int getRow()
    {
        return row;
    }

    /**
     * @return The column.
     */
    public int getCol()
    {
        return col;
    }

    /**
     * Increases the length of the grass if it is not already fully grown.
     */
    public void increaseGrassLength()
    {
        if(!fullyGrown){
            if(grassLength< maxGrassLength){
                grassLength++;
            }
            else{
                fullyGrown = true;
            }
        }
    }

    /**
     * Increases the length of the grass by the given parameter.
     * @param increaseValye The value to increase the length of the grass by
     */
    public void increaseGrassLengthBy(int increaseValue)
    {
        if((grassLength+increaseValue) <= maxGrassLength){
            grassLength += increaseValue;
        }
        else{
            grassLength = maxGrassLength;
        }

    }

    /**
     * Resets the stats of the grass when it has been eaten.
     */
    public void grassEaten()
    {
        fullyGrown = false;
        grassLength = 0;
    }

    /**
     * @return The status of the grass.
     */
    public boolean isFullyGrown()
    {
        return fullyGrown;
    }
}
