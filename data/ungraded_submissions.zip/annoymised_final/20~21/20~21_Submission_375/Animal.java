import java.util.List;
import java.util.Random;

/**
 * A class representing shared characteristics of animals.
 *
 * @version 2016.02.29 (2)
 */
public abstract class Animal
{
    // Whether the animal is alive or not.
    private boolean alive;
    // The animal's field.
    private Field field;
    // The animal's position in the field.
    private Location location;
    // The animal's gender
    private boolean gender;
    
    private static final Random rand = Randomizer.getRandom();
    // The animal's that are infected
    private boolean infected;

    
    /**
     * Create a new animal at location in field.
     * 
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Animal(Field field, Location location)
    {
        alive = true;
        Random random = new Random();
        this.gender = random.nextBoolean();
        this.infected = getsInfected();
        this.field = field;
        setLocation(location);
    }
    
    /**
     * Make this animal act - that is: make it do
     * whatever it wants/needs to do.
     * @param newAnimals A list to receive newly born animals.
     */
    abstract public void act(List<Animal> newAnimals);

    /**
     * Check whether the animal is alive or not.
     * @return true if the animal is still alive.
     */
    protected boolean isAlive()
    {
        return alive;
    }

    /**
     * Indicate that the animal is no longer alive.
     * It is removed from the field.
     */
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }

    /**
     * Return the animal's location.
     * @return The animal's location.
     */
    protected Location getLocation()
    {
        return location;
    }
    
    /**
     * Place the animal at the new location in the given field.
     * @param newLocation The animal's new location.
     */
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    
    /**
     * Return the animal's field.
     * @return The animal's field.
     */
    protected Field getField()
    {
        return field;
    }
    
    /**
     * Get gender of the animal.
     * 
     * @return The animal's gender, true for male, false for female.
     */
    public boolean getGender(){
        return gender;
    }
    
    /**
     * This will be true if an animal in the simulation
     *  is effected by the disease.
     *  
     *  @return True if animal is infected, otherwise fasle.
     */
    public boolean isInfected()
    {
        return infected;
    }

    /**
     * This is the probability that an animal get randomly infected
     * with a probability of 1%.
     * 
     * @return This will return true if infect chance is true, otherwise false.
     */
    public boolean getsInfected()
    {
        Random random = new Random();
        //sets probability of infection to 1%
        boolean infect = (random.nextInt(100) == 0);
        if (infect == true){
            infected = true;
            return infected;
        }
        else{
            return infected;
        }
    }
    
    /**
     * This is the proability if an animal recovers with a 50% chance of recovery.
     * 
     * @return false infected if the animal has recovered, otherwise true still infected.
     */
    public boolean recovered()
    {  
        Random random = new Random();
        boolean heal = (random.nextInt(2) == 0);
        if (heal == true) {
            infected = false;
            return infected;        
        }
        return infected;
    }
}
