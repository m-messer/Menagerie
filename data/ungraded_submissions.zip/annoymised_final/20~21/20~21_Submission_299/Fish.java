import java.util.List;
import java.util.Random;
import java.util.Iterator;
/**
 * A simple model of a fish.
 * Fishs age, move, breed, and die.
 *
 * @version 2021.02.26 
 */
public class Fish extends Creature  
{
    // Characteristics shared by all fishs (class variables).

    // The age at which a fish can start to breed.
    private static final int BREEDING_AGE = 5;
    // The age to which a fish can live.
    private static final int MAX_AGE = 100;
    // The likelihood of a fish breeding.
    private static final double BREEDING_PROBABILITY = 0.15;
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 4;
    // A shared random number generator to control breeding.
    private static final int PLANT_FOOD_VALUE = 30;
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    
   // Individual characteristics (instance fields).
    

    /**
     * Create a new fish. A fish may be created with age
     * zero (a new born) or with a random age.
     * 
     * @param randomAge If true, the fish will have a random age.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Fish(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    /**
     * Look for algae adjacent to the current location.
     * Only the first live algae is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object plant = field.getObjectAt(where);
            if(plant instanceof Algae) {
                Algae algae = (Algae) plant;
                    algae.setDead();
                    incrementFoodLevel();
                    return where;
                }
            }
        
        return null;
    }

    /**
      * This method overrides the getFoodValue() method in Creature 
      * @return the Constant PLANT_FOOD_VALUE specific to the object  * type
    **/
    public int getFoodValue()
    {
      return PLANT_FOOD_VALUE;
    }

    /**
      * This method overrides the getMaxAge() method in Creature 
      @return the Constant MAX_AGE specific to the object type
    **/
    public int getMaxAge()
    {
      return MAX_AGE;
    }

    /**
      * This method overrides the getMaxLitterSize() method in Creature, 
      @return the Constant MAX_LITTER_SIZE specific to the object type
    **/
    public int getMaxLitterSize()
    {
      return MAX_LITTER_SIZE;
    }
    /**
      * This method overrides the getBreedingProbability() method in Creature, @return the Constant BREEDING_PROBABILITY specific to the object type
    **/
    public double getBreedingProbability()
    {
      return BREEDING_PROBABILITY;  
    }  
    /**
      * This method overrides the getBreedingAge() method in Creature 
      * @return the Constant BREEDING_AGE specific to the object type
    **/
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }

    /**
     * This is what the fish does most of the time - it runs 
     * around. Sometimes it will breed or die of old age.
     * @param newFishs A list to return newly born fishs.
     */
    public void act(List<Organism> newFishs, boolean isDay)
    {  
        super.act(newFishs, isDay);
        if(isAlive()) {
            giveBirth(newFishs);            
        }
    }
    
    /**
     * Check whether or not this fish is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newFishs A list to return newly born fishs.
     */
    public void giveBirth(List<Organism> newFishs)
    {
        // New fishs are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Fish young = new Fish(false, field, loc);
            newFishs.add(young);
        }
    }

  /**
      * This method checks the neighbouring cell contains an fish of the
      * opposite gender   
      * @return the Boolean isOppositeGender
    **/      
  protected boolean isOppositeGender(Object occupant) 
    {
      boolean isOppositeGender = false;
      if (occupant instanceof Fish){
            Fish fish = (Fish) occupant;
            if (fish.getIsFemale() != this.getIsFemale()) {
              isOppositeGender = true;
            } //XOR only one can be true
          }
        return isOppositeGender;
        //return true;
    }

   
}
