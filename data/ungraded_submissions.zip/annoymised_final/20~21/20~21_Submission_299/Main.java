class Main {
  public static void main(String[] args) { 


    //Simulator sim1 = new Simulator();
    //sim1.simulate(500);
    Simulator sim2 = new Simulator(100,150);
    sim2.simulate(4000);

  }
}