import java.util.List;
import java.util.Iterator;
import java.util.Random;

/**
 * A simple model of a otter.
 * Otters age, move, eat fish, and die.
 *
 * @version 2016.02.29 (2)
 */
public class Otter extends Creature

{ 
    // Characteristics shared by all otters (class variables).
    
    // The age at which a can start to breed.
    private static final int BREEDING_AGE = 15;
    // The age to which a otter can live.
    private static final int MAX_AGE = 150;
    // The age to which a otter can live if infected by a disease.
    private static final int INFECTED_MAX_AGE = 75;
    // The likelihood of a otter breeding.
    private static final double BREEDING_PROBABILITY = 0.15;//0.20;//0.80;//0.10
    // The likelihood of a otter getting a disease.
    private static final double INFECTION_RATE = 0.25;//0.10
    // The maximum number of births.
    private static final int MAX_LITTER_SIZE = 2;
    // The food value of a single fish. In effect, this is the
    // number of steps a otter can go before it has to eat again.
    private static final int FISH_FOOD_VALUE = 18; //9
    // A shared random number generator to control breeding.
    private static final Random rand = Randomizer.getRandom();
    

    /**
     * Create a Otter. A otter can be created as a new born (age zero
     * and not hungry) or with a random age and food level.
     * 
     * @param randomAge If true, the otter will have random age and hunger level.
     * @param field The field currently occupied.
     * @param location The location within the field.
     */
    public Otter(boolean randomAge, Field field, Location location)
    {
        super(randomAge, field, location);
    }
    
    
    /**
     * This is what the otter does most of the time: it hunts for
     * fish. In the process, it might breed, die of hunger,
     * or die of old age.
     * @param field The field currently occupied.
     * @param newOtters A list to return newly born otters.
     */
    public void act(List<Organism> newOtters, boolean isDay)
    {   if (!isDay) {
          super.act(newOtters, isDay);
          if(isAlive()) {
              giveBirth(newOtters);            
          }
      }
    }

    /**
     * Value of the food
     * @return int How many additional steps the otter can go before it dies of hunger
     */
    public int getFoodValue()
    {
      return FISH_FOOD_VALUE;
    }
    /**
    * The rate of transmission and initial infection for any disease the otter is 
    * susceptible to
    * @return double INFECTION_RATE 
    */
    public double getInfectionRate()
    {
      return INFECTION_RATE;
    }
    
    /**
     * Look for fish adjacent to the current location.
     * Only the first live fish is eaten.
     * @return Where food was found, or null if it wasn't.
     */
    public Location findFood()
    {
        Field field = getField();
        List<Location> adjacent = field.adjacentLocations(getLocation());
        Iterator<Location> it = adjacent.iterator();
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Fish) {
                Fish fish = (Fish) animal;
                if(fish.isAlive()) { 
                    fish.setDead();
                    incrementFoodLevel();
                    return where;
                }
            }
            if(animal instanceof Frog) {
                  Frog frog = (Frog) animal; 
                  if(frog.isAlive()) { 
                      frog.setDead();
                      incrementFoodLevel();
                      return where;
                  }
              
            }
        }
        return null;
      
    }
    
    
    /**
     * Check whether or not this otter is to give birth at this step.
     * New births will be made into free adjacent locations.
     * @param newOtters A list to return newly born otters.
     */
    public void giveBirth(List<Organism> newOtters)
    {
        // New otters are born into adjacent locations.
        // Get a list of adjacent free locations.
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed();
        for(int b = 0; b < births && free.size() > 0; b++) {
            Location loc = free.remove(0);
            Otter young = new Otter(false, field, loc);
            newOtters.add(young);
        }
    }

    /**
      * This method overrides the getMaxAge() method in Creature, returns the Constant 
      * MAX_AGE if the creature is not infected and returns a smaller Constant in 
      * INFECTED_MAX_AGE if the creature is diseased
      @return int AGE
    **/
    protected int getMaxAge()
    {
      if (getIsInfected()){
        return INFECTED_MAX_AGE;
      }
      else{
        return MAX_AGE;
      }
    }
    /**
      * This method overrides the getMaxLitterSize() method in Creature, 
      @return the Constant MAX_LITTER_SIZE specific to the object type
    **/
    public int getMaxLitterSize()
    {
      return MAX_LITTER_SIZE;
    }
    /**
      * This method overrides the getBreedingAge() method in Creature, 
      * @return the Constant BREEDING_AGE specific to the object type
    **/
    public int getBreedingAge()
    {
        return BREEDING_AGE;
    }
    /**
      * This method overrides the getBreedingProbability() method in Creature,   
      * @return the Constant BREEDING_PROBABILITY specific to the object type
    **/
    public double getBreedingProbability()
    {
      return BREEDING_PROBABILITY;  
    }   

    /**
      
      * This method returns true because Otters will 
      * reproduce regardless of their neighbours gender  
      * @return the Boolean true
    **/
    protected boolean isOppositeGender(Object occupant) 
    {
      return true;
    }
    
}
