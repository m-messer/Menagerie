import java.util.Random;
import java.util.List;
import java.util.Iterator;

/**
* A simple model of a algae.
* Algae reproduce and die of old age
*
* @version 2021.02.26 
*/
public class Algae extends Plant{

   private static final double BREEDING_PROBABILITY =0.30; //0.25;
   // The maximum number of births.
   private static final int MAX_LITTER_SIZE = 1;
   // A shared random number generator to control reproduction.
   private static final Random rand = Randomizer.getRandom();
   // The likelihood of an algae dying in the case of freezing.
    private static final double FREEZING_DEATH_PROBABILITY = 0.4; 
   // The age to which a algae can live.
   private static final int MAX_AGE = 20;

      /**
     * Create a new algae. An locust will be created with age
     * zero.
     * @param field The field currently occupied.
     * @param location The location within the field.
     **/
  public Algae(Field field, Location location){
    super(field, location);

   }
  
    /**
     * This is what the algae during the day day: it hunts for
     * fish. In the process, it might have offspring or die.
     * @param isDay Whether it is currently day or night.
     * @param newOtters A list to return new algae.
     */ 
   public void act(List<Organism> newAlgae, boolean isDay)
   {
    if(isDay){
      incrementAge();
      if(isAlive()) {
          giveBirth(newAlgae);
          if ( !findSpace() ) {
              setDead();
          } 
    }
   }  
  }
  
  /**
     * This checks around the algae to see if there are any available
     * spaces.
     * @return isSpace A boolean to indicate whether or not space is 
     * available.
     */ 
  public boolean findSpace()
  {
    Field field = getField();
    boolean isSpace = false;
    Location adjacent = field.freeAdjacentLocation(getLocation());
    if(adjacent != null) {
        isSpace = true;
    }
    return isSpace;
  }

  /**
  * Check whether or not this algae is to reproduce at this step.
  * New algae will be made into free adjacent locations.
  * @param newAlgae A list to return new algae.
  */
  public void giveBirth(List<Organism> newAlgaes) {
    Field field = getField();
    List<Location> free = field.getFreeAdjacentLocations(getLocation());
    int births = breed();
    for (int b = 0; b < births && free.size() > 0; b++) {
      Location loc = free.remove(0);
      Algae young = new Algae(field, loc);
      newAlgaes.add(young);
    }
  }

      /**
      * This method overrides the getMaxLitterSize() method in Creature, 
      @return the Constant MAX_LITTER_SIZE specific to the object type
    **/
    public int getMaxLitterSize()
    {
      return MAX_LITTER_SIZE;
    }

    /**
      * This method overrides the getMaxAge() method in Creature 
      @return the Constant MAX_AGE specific to the object type
    **/
    public int getMaxAge()
    {
      return MAX_AGE;
    }

    /**
      * This method overrides the getBreedingProbability() method in Creature, @return the Constant BREEDING_PROBABILITY specific to the object type
    **/
    public double getBreedingProbability()
    {
      return BREEDING_PROBABILITY;  
    } 

    /**
     * Checks whether or not an algae succumb to the freezing 
     * temperature. If the random number is less than the 
     * FREEZING_DEATH_PROBABILITY, then it is set as dead.
     */
    public void freezeDeathGenerator()
    {
    double deathProbability = rand.nextDouble();
    if(deathProbability <= FREEZING_DEATH_PROBABILITY)
    {
      setDead();
    }

}
}
